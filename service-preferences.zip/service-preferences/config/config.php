<?php
ini_set("error_reporting", "true");
error_reporting(E_ALL);

define('ENV_TYPE', 'dev');

require_once '../lib/meekrodb.2.3.class.php';
require_once '../lib/ims-blti/blti.php';
require_once '../lib/sodium_compat/autoload.php';

require_once '../lib/CanvasAPI.php';
require_once '../lib/PreferencesDataApi.php';


require_once '../lib/Preferences.php';

require_once '../lib/utils.php';
require_once '../lib/Log.php';


// Database connection information for Template Wizard

DB::$host ='mysql.usu.edu';
DB::$user = 'elearnuser';
DB::$password = '4UmYcwCJbjxf00uvrNG4';
DB::$dbName = 'elearn';

$oauth_redirect_url = 'https://elearn.usu.edu/ludovic/service-preferences/public/oauth2response.php';
// var_dump($oauth_redirect_url);

$ga_code = '';

$version = '1.0-dev';

if (PHP_VERSION_ID < 70300) {
    // Hack to set SAMESITE=NONE and SECURE=TRUE for the session cookie
    session_set_cookie_params(0, '/; samesite=none;', NULL, TRUE, FALSE);
} else {
    $cookieOptions = [
        'lifetime' => 0,
        'path' => '/',
        'domain' => NULL,
        'samesite' => 'None',
        'secure' => TRUE,
        'httponly' => FALSE,
    ];
    session_set_cookie_params($cookieOptions);
}

session_start();
// print("config");


ServicePreferencesUtils::instance()->setup();

