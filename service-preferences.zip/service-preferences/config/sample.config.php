<?php

ini_set("error_reporting", "true");
error_reporting(E_ALL);

define('ENV_TYPE', 'stage');

require_once '../lib/meekrodb.2.3.class.php';
require_once '../lib/ims-blti/blti.php';
require_once '../lib/CanvasApi.php';
require_once '../lib/Course.php';
require_once '../lib/ContentItem.php';
require_once '../lib/utils.php';
require_once '../lib/Log.php';

// Database connection information for Template Wizard
DB::$host ='localhost';
DB::$user = 'root';
DB::$password = 'root';
DB::$dbName = 'tidyup';

$oauth_redirect_url = '<yoursite>/oauth2response.php';
$ga_code = '';

$version = '1.0-dev';

session_start();

TidyUpUtils::instance()->setup();
