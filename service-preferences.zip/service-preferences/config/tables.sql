# Dump of table institutions
# ------------------------------------------------------------

CREATE TABLE `ce_institutions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `developer_id` varchar(64) NOT NULL,
  `developer_key` varchar(128) NOT NULL DEFAULT '',
  `consumer_key` varchar(128) NOT NULL DEFAULT '',
  `shared_secret` varchar(128) NOT NULL DEFAULT '',
  `canvas_domain` varchar(128) NOT NULL DEFAULT '',
  `vanity_url` varchar(128) DEFAULT NULL,
  `metadata` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table users
# ------------------------------------------------------------

CREATE TABLE `ce_users` (
  `canvas_user_id` int(11) unsigned NOT NULL,
  `canvas_domain` varchar(128) NOT NULL DEFAULT '',
  `api_key` varchar(256) NOT NULL DEFAULT '',
  `refresh_token` varchar(128) NOT NULL DEFAULT '',
  `created` int(11) NOT NULL,
  UNIQUE KEY `canvas_user_id_domain` (`canvas_user_id`,`canvas_domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


# Dump of table gl_log
# ------------------------------------------------------------

CREATE TABLE `ce_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(32) DEFAULT NULL,
  `message` text,
  `severity` varchar(32) DEFAULT NULL,
  `location` varchar(256) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `metadata` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;