#!/bin/bash

# change to the new file location
cd /var/www/html

# run composer install
# composer install --no-dev --no-interaction --no-progress --optimize-autoloader

# copy localConfig
if [ "$DEPLOYMENT_GROUP_NAME" == "TidyUpProd" ]
then
    cp /var/www/deploy/tidyup/config.prod.php /var/www/html/config/config.php
else
    cp /var/www/deploy/tidyup/config.stage.php /var/www/html/config/config.php
fi

# change all file and directory permissions to give apache sufficient access
sudo find /var/www/html -type f -exec chmod 664 {} + -o -type d -exec chmod 775 {} +

# change localConfig owner and perms
sudo chown ssm-user:apache /var/www/html/config/config.php
sudo chmod 440 /var/www/html/config/config.php

# add New Relic appname
if [ "$DEPLOYMENT_GROUP_NAME" == "TidyUpProd" ]
then
    echo -e "\nnewrelic.appname = \"TidyUp Production\"" >> /etc/php.d/newrelic.ini
else
    echo -e "\nnewrelic.appname = \"TidyUp Staging\"" >> /etc/php.d/newrelic.ini
fi

# create a tmp folder
sudo mkdir /var/www/html/tmp
sudo chown ssm-user:apache /var/www/html/tmp
sudo chmod 777 /var/www/html/tmp

sudo apachectl restart
