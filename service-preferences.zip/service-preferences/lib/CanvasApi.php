<?php

namespace ServicePreferences;

/**
 * Class CanvasApi.
 */
class CanvasApi
{

    protected $domain;

    protected $tokenHeader;

    // public $typeMap = [
    //     "page" => "pages",
    //     "announcement" => "discussion_topics",
    //     "discussion" => "discussion_topics",
    //     "quiz" => "quizzes",
    //     "assignment" => "assignments"
    // ];

    public function __construct($domain = NULL, $token_header = NULL)
    {
        $this->domain = !empty($domain) ? $domain : $GLOBALS['domain'];
        $this->tokenHeader = !empty($token_header) ? $token_header : $GLOBALS['tokenHeader'];
    }

    /****************************************
     ********  CURL FUNCTIONS  **************
     ****************************************/

    public function curlGet($url, $return_array = FALSE)
    {
        $per_page = 100;

        if (!strpos($url, 'per_page')) {
            if (strpos($url, '?')) {
                $url .= '&per_page=' . $per_page;
            } else {
                $url .= '?per_page=' . $per_page;
            }
        }

        $ch = curl_init($url);

        if (strpos($url, $this->domain) !== false) {
            curl_setopt($ch, CURLOPT_URL, $url);
        } else {
            curl_setopt($ch, CURLOPT_URL, 'https://' . $this->domain . '/api/v1/' . $url);
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->tokenHeader);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // ask for results to be returned
        curl_setopt($ch, CURLOPT_VERBOSE, 0); //Requires to load headers
        curl_setopt($ch, CURLOPT_HEADER, 1);  //Requires to load headers

        $result = curl_exec($ch);

        #Parse header information from body response
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $header = substr($result, 0, $header_size);
        $body = substr($result, $header_size);
        $data = json_decode($body, $return_array);
        curl_close($ch);

        #Parse Link Information
        $header_info = $this->httpParseHeaders($header);

        if (isset($header_info['Link']) || isset($header_info['link'])) {
            $header_links = isset($header_info['Link']) ? $header_info['Link'] : $header_info['link'];
            $links = explode(',', $header_links);

            foreach ($links as $value) {
                if (preg_match('/^\s*<(.*?)>;\s*rel="(.*?)"/', $value, $match)) {
                    $links[$match[2]] = $match[1];
                }
            }
        }
        #Check for Pagination
        if (isset($links['next'])) {
            // Remove the API url so it is not added again in the get call
            $next_link = str_replace('https://' . $this->domain . '/api/v1/', '', $links['next']);
            $next_data = $this->curlGet($next_link, $return_array);
            $data = array_merge($data, $next_data);

            return $data;
        } else {
            return $data;
        }
    }

    public function curlPost($url, $data)
    {
        $ch = curl_init();

        if (strpos($url, $this->domain) !== false) {
            curl_setopt($ch, CURLOPT_URL, $url);
        } else {
            curl_setopt($ch, CURLOPT_URL, 'https://' . $this->domain . '/api/v1/' . $url);
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->tokenHeader);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); // ask for results to be returned

        // Send to remote and return data to caller.
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    public function curlPut($url, $data)
    {
        $ch = curl_init();

        if (strpos($url, $this->domain) !== false) {
            curl_setopt($ch, CURLOPT_URL, $url);
        } else {
            curl_setopt($ch, CURLOPT_URL, 'https://' . $this->domain . '/api/v1/' . $url);
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->tokenHeader);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // ask for results to be returned

        // Send to remote and return data to caller.
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    public function curlDelete($url)
    {
        $ch = curl_init();

        if (strpos($url, $this->domain) !== false) {
            curl_setopt($ch, CURLOPT_URL, $url);
        } else {
            curl_setopt($ch, CURLOPT_URL, 'https://' . $this->domain . '/api/v1/' . $url);
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->tokenHeader);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // Send to remote and return data to caller.
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    public function curlAllGet($url) {
     
        $ch = curl_init($url);
        if (strpos($url, $GLOBALS['domain']) !== false) {
            curl_setopt ($ch, CURLOPT_URL, $url);
        } else {
              curl_setopt ($ch, CURLOPT_URL, 'https://'.$GLOBALS['domain'].'/api/v1/'.$url);
        }
        curl_setopt ($ch, CURLOPT_HTTPHEADER, $GLOBALS['tokenHeader']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // ask for results to be returned
        curl_setopt($ch, CURLOPT_VERBOSE, 1); //Requires to load headers
        curl_setopt($ch, CURLOPT_HEADER, 1);  //Requires to load headers
        // curl_setopt($ch, CURLOPT_TIMEOUT, 500);
        // curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
        // curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
        $result = curl_exec($ch);
        // var_dump($result);
        #Parse header information from body response
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $header = substr($result, 0, $header_size);
        $body = substr($result, $header_size);
        $data = json_decode($body);
        curl_close($ch);
        
        #Parse Link Information
        $header_info = $this->httpParseHeaders($header);

        if (isset($header_info['Link']) || isset($header_info['link'])) {
            $header_links = isset($header_info['Link']) ? $header_info['Link'] : $header_info['link'];
            $links = explode(',', $header_links);

            foreach ($links as $value) {
                if (preg_match('/^\s*<(.*?)>;\s*rel="(.*?)"/', $value, $match)) {
                    $links[$match[2]] = $match[1];
                }
            }
        }
        #Check for Pagination
        if (isset($links['next'])) {
            // Remove the API url so it is not added again in the get call
            $next_link = str_replace('https://' . $this->domain . '/api/v1/', '', $links['next']);
            $next_data = $this->curlGet($next_link, $return_array);
            $data = array_merge($data, $next_data);

            return $data;
        } else {
            return $data;
        }
    }

    public function getDomain()
    {
        return $this->domain;
    }

    public function getTokenHeader()
    {
        return $this->tokenHeader;
    }

    /****************************************
     ********  CRUD FUNCTIONS  **************
     ****************************************/

    /**
     * Scope: url:GET|/api/v1/courses/:id
     * Scope: url:GET|/api/v1/courses/:course_id/assignments
     * Scope: url:GET|/api/v1/courses/:course_id/discussion_topics
     * Scope: url:GET|/api/v1/courses/:course_id/discussion_topics/:topic_id/entries
     * Scope: url:GET|/api/v1/courses/:course_id/modules
     * Scope: url:GET|/api/v1/courses/:course_id/pages
     * Scope: url:GET|/api/v1/courses/:course_id/pages/:url
     * Scope: url:GET|/api/v1/courses/:course_id/quizzes
     * Scope: url:GET|/api/v1/courses/:course_id/quizzes/:quiz_id/questions
     * Scope: url:GET|/api/v1/courses/:course_id/folders
     *  
     * @param $course_id
     *      Course ID
     * @param $content_type
     *      Content type (assignments, quizzes, etc)
     * @param string $item_id
     *      Returns a single item rather than an array
     * @param string $params
     *      Query parameters added to the end of the CURL request
     * @param string $path_suffix
     *      Some paths have something after the item ID (i.e. courses/:course_id/quizzes/:quiz_id/questions)
     *
     * @return array
     */
    public function getCourseContent($course_id, $content_type, $item_id = '', $params = '')
    {
        $url = 'courses/' . $course_id;

        if ($content_type) {
            $url .= '/' . $content_type;
        }

        if ($item_id) {
            $url .= '/' . $item_id;
        }

        return $this->curlGet($url . $params);
    }

    public function getCourseInfo($courseID, $getCourseInfo)
    {
        $url = "courses/".$courseID."?include[]=teachers&include[]=account&include[]=sections";
      
        return  $this->curlAllGet($url);
    }
    public function listUserCourse(){
  
        return $this->curlAllGet("courses/");
    }

    public function getCourseSections($courseID)
    {
        $url = "courses/".$courseID."/sections/";
     
        return  $this->curlAllGet($url);
    }
    public function getSyllabus($courseID)
    {
        $url = "courses/".$courseID."?include[]=syllabus_body";

        return $this->curlAllGet($url);
    }
    public function getFrontPage($courseID)
    {
        $url = "courses/".$courseID."/front_page";
 
        return $this->curlAllGet($url);
    }
    public function gettabs($courseID)
    {
        $url = "courses/".$courseID."/tabs";
        return $this->curlAllGet($url);
    }
    public function getTeachers($courseID)
    {
        $url = "courses/".$courseID."/enrollments?type[]=TeacherEnrollment";

        return $this->curlAllGet($url);
    }
        public function getSections($courseID)
    {
        $url = "courses/".$courseID."?include[]=sections";

        return $this->curlAllGet($url);
    }
    public function listTerm(){
        $response = $this->curlGet("accounts/self/terms?per_page=100");
        return $response;
    }

    public function getCourse($courseID)
    {
        $url = "courses/".$courseID."?include[]=term&include[]=teachers";
        return $this->curlAllGet($url);
    }
    public function getAnnouncements($courseID, $startAt, $endDate)
    {
        $url = "announcements?context_codes[]=course_".$courseID."&start_date=".$startAt."&end_date=".$endDate;
        return $this->curlAllGet($url);
    }

    public function getAssignments($courseID)
    {
        
        $url = "courses/".$courseID."/assignments";
      
        return $this->curlAllGet($url);
    }
    public function getFiles($courseID)
    {
        $url = "courses/".$courseID."/files";
 
        return $this->curlAllGet($url);
    }

    public function getAccount($accountsID)
    {
        $url = "accounts/".$accountsID;
        
        return $this->curlAllGet($url);
    }
    public function getModules($courseID)
    {
        $url = "courses/".$courseID."/modules?include[]=items";
 
        return  $this->curlAllGet($url);
    }
    public function getQuizzes($courseID)
    {
        $url = "courses/".$courseID."/quizzes";
     
        return $this->curlAllGet($url);
    }
    public function getPages($courseID)
    {
        $url = "courses/".$courseID."/pages";

        return $this->curlAllGet($url);
    }
    public function getDiscussionTopic($courseID, $topicID)
    {
        $url = "courses/".$courseID."/discussion_topics/".$topicID."/view";
        
        return $this->curlAllGet($url);
    }

    public function getPagesByURL($courseID, $pageUrl)
    {
        $url = "courses/".$courseID."/pages/".$pageUrl;
   
        return $this->curlAllGet($url);
    }
    public function getSettings($courseID)
    {
        $url = "courses/".$courseID."/settings";

        return $this->curlAllGet($url);
    }
    public  function getDiscussion($courseID)
    {
        $url = "courses/".$courseID."/discussion_topics";

        return $this->curlAllGet($url);
    }
    // public function getStudents($courseID)
    // {
    //     $url = "courses/".$courseID."/users?enrollment_type[]=student&include[]=email&include[]=avatar_url";
    
    //     return $this->curlAllGet($url);
    // }
    public function studentSummaryData($courseID, $userID)
    {
        $url = "courses/".$courseID."/analytics/student_summaries?student_id=".$userID;

        return $this->curlAllGet($url);
    }

    public function studentAssignmentData($courseID, $userID)
    {
        $url = "courses/".$courseID."/analytics/users/".$userID."/assignments";
  
        return $this->curlAllGet($url);
    }

    public function getuser($userID){

        $url = "users/".$userID."/profile";
        
        return $this->curlAllGet($url);
         
    }

    public function createconversations($userID, $subject, $message){

        $apiUrl = "conversations";
        $apiParams = "recipients[]=".$userID."&subject=".$subject."&body=".$message;
        $response = $this->curlPost($apiUrl, $apiParams);
        return $response;

    }


    public function createCaseAnnouncement($courseID,$title,$message){
        // var_dump($message);
        // exit();
        $apiUrl = "courses/".$courseID."/discussion_topics/";
        $apiParams = "title=".$title."&message=".$message."&is_announcement=true&published=true&pinned=true";

        $response = $this->curlPost($apiUrl, $apiParams);
        return $response;

    }

    public function getStudents($courseID){

        $url = "courses/".$courseID."/enrollments?type[]=StudentEnrollment";
        return $this->curlAllGet($url);
    }



    protected function httpParseHeaders($raw_headers) {
        $headers = array();
        $key = '';

        foreach(explode("\n", $raw_headers) as $i => $h) {
            $h = explode(':', $h, 2);

            if (isset($h[1])) {

                if (!isset($headers[$h[0]])){
                    $headers[$h[0]] = trim($h[1]);
                } elseif (is_array($headers[$h[0]])) {
                    $headers[$h[0]] = array_merge($headers[$h[0]], array(trim($h[1])));
                } else {
                    $headers[$h[0]] = array_merge(array($headers[$h[0]]), array(trim($h[1])));
                }

                $key = $h[0];
            } else {
                if (substr($h[0], 0, 1) == "\t")
                    $headers[$key] .= "\r\n\t".trim($h[0]);
                elseif (!$key)
                    $headers[0] = trim($h[0]);
            }
        }
        return $headers;
    }

}