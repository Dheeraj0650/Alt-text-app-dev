<?php

namespace CidiLabs;

class Log {
    protected static $types = [
        'info',
        'error',
        'debug',
    ];

    protected static $severity = [
        'low',
        'high',
        'critical'
    ];

    static function insert($msg, $location, $type = 'info', $severity = 'low', $meta = [])
    {
        if (!in_array($type, self::$types)) {
            $type = reset(self::$types);
        }
        if (!in_array($severity, self::$severity)) {
            $severity = reset(self::$severity);
        }
        if (!is_string($msg)) {
            $msg = json_encode($msg);
        }

        \DB::insert('ce_logs', [
            'type' => $type,
            'message' => $msg,
            'severity' => $severity,
            'location' => $location,
            'timestamp' => date('Y-m-d H:i:s'),
            'metadata' => \json_encode($meta),
        ]);
    }

    static function debug($msg, $location, $meta = [])
    {
        $debug = filter_input(INPUT_GET, 'debug', FILTER_SANITIZE_NUMBER_INT);

        if ($debug) { // || (ENV_STATUS == ENV_DEV)) {
            self::insert($msg, $location, 'debug', 'low', $meta);
        }
    }
}