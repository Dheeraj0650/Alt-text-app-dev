<?php

namespace ServicePreferences;
/**
 * Class Evaluation
 * @package CourseEvaluation
 */

class Preferences {

    /** @var \CourseEvaluation\CanvasApi $canvasApi */
    protected $canvasApi;

     public function __construct($course_id)
    {
        $this->canvasApi = new CanvasApi();
      
        $this->preferencesDataApi = new PreferencesDataApi();
    }



    public function retrievePreferences()
    {

        $results =  \DB::query("SELECT * FROM  service_preferences");
    
        print json_encode($results);

    }   
    public function retrieveUsers($userID)
    {
      
        $response = $this->preferencesDataApi->getUsers($userID);

        print $response ;

    } 
    public function retrieveMyPreferences()
    {
        $aNumber =$_SESSION['login_id'];
        $result =  \DB::queryFirstRow("SELECT * FROM  service_preferences WHERE aNumber=%s", $_SESSION['login_id']);
        if (isset($result)) {
            print json_encode($result);
        } else {

            \DB::insert('service_preferences', array (
                'aNumber' => $_SESSION['login_id'],
                'displayName' => $_SESSION['fullName'],
                'updateAt' => \DB::sqleval("NOW()")

                )
            );

            $result =  \DB::queryFirstRow("SELECT * FROM  service_preferences WHERE aNumber=%s", $_SESSION['login_id']);
            print json_encode($result);
        }
        
    } 
    public function updateMyPreferences($fieldName, $fieldValue)
    {
    
        \DB::update('service_preferences', [$fieldName => $fieldValue], "aNumber=%s", $_SESSION['login_id']);

    } 
    public function updateMyInterests($fieldName, $fieldValue)
    {
        // // $interestList = json_decode($interests);
        // // $jArr = json_decode($interestList, true);
        var_dump($fieldName);
        var_dump($fieldValue);
        // foreach ($interests as $interest) {
        //     var_dump($interest);
        //     $fieldName= $interest->fieldName;
        //     $fieldValue= $interest->value;
            
        //    \DB::update('service_preferences', [$fieldName => $fieldValue], "aNumber=%s", $_SESSION['login_id']);
        // }
    
        \DB::update('service_preferences', [$fieldName => $fieldValue], "aNumber=%s", $_SESSION['login_id']);

  
    } 
    // public function retrievePreferences()
    // {


    //     $url = 'https://vm-01.tlt.usu.edu/api/preferences';
 
    //     $curl = curl_init();
         
    //     curl_setopt($curl, CURLOPT_URL, $url);
    //     curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    //     curl_setopt($curl, CURLOPT_HEADER, false);
         
    //     $data = curl_exec($curl);
         
    //     curl_close($curl);
        
    //     print json_encode($data) ;


    // }   

}