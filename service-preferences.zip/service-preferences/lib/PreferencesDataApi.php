<?php

namespace ServicePreferences;
/**
 * Class PreferencesDataApi.
 */

class PreferencesDataApi
{
    


    protected $usuTokenHeader = array(
        "Content-Type: application/json",
        "Authorization: Basic VVNVQGBxdlBjKUIucWVWZzBFTFYqc3pGVDNKZlZiWVVGOkpeRytdSU9JPGQoZj5LNCFYWT83RmQ7fEE3W2AwUw=="
    );


    public function __construct($domain = NULL, $token_header = NULL)
    {  
        $this->domain = !empty($domain) ? $domain : $GLOBALS['domain'];
        $this->tokenHeader = !empty($token_header) ? $token_header : $GLOBALS['tokenHeader'];

    }

    /****************************************
     ********  CURL FUNCTIONS  **************
     ****************************************/

    public function ucurlGet($url, $return_array = FALSE)
    {
        $per_page = 100;

        if (!strpos($url, 'page')) {
            if (strpos($url, '?')) {
                $url .= '&page=' . $per_page;
            } else {
                $url .= '?page=' . $per_page;
            }
        }

        $ch = curl_init($url);

        if (strpos($url, $this->domain) !== false) {
            curl_setopt($ch, CURLOPT_URL, $url);
        } else {
            curl_setopt($ch, CURLOPT_URL, 'https://vm-01.tlt.usu.edu/api/' . $url);
        }

        // curl_setopt($ch, CURLOPT_HTTPHEADER, $this->usuTokenHeader);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // ask for results to be returned
        curl_setopt($ch, CURLOPT_VERBOSE, 0); //Requires to load headers
        curl_setopt($ch, CURLOPT_HEADER, 1);  //Requires to load headers

        $result = curl_exec($ch);

        #Parse header information from body response
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $header = substr($result, 0, $header_size);
        $body = substr($result, $header_size);
        $data = json_decode($body, $return_array);
        var_dump($data);
        curl_close($ch);

        #Parse Link Information
        $header_info = $this->httpParseHeaders($header);

        if (isset($header_info['Link']) || isset($header_info['link'])) {
            $header_links = isset($header_info['Link']) ? $header_info['Link'] : $header_info['link'];
            $links = explode(',', $header_links);

            foreach ($links as $value) {
                if (preg_match('/^\s*<(.*?)>;\s*rel="(.*?)"/', $value, $match)) {
                    $links[$match[2]] = $match[1];
                }
            }
        }
             // var_dump($data);
        // exit();
        #Check for Pagination
        if (isset($links['next'])) {
            // Remove the API url so it is not added again in the get call
            $next_link = str_replace('https://vm-01.tlt.usu.edu/api/', '', $links['next']);
            $next_data = $this->ucurlGet($next_link, $return_array);
            $data = array_merge($data, $next_data);
            return $data;
        } else {
            return $data;
        }
    }

    // public function ucurlPost($url, $data)
    // {
    //     $ch = curl_init();

    //     if (strpos($url, $this->domain) !== false) {
    //         curl_setopt($ch, CURLOPT_URL, $url);
    //     } else {
    //         curl_setopt($ch, CURLOPT_URL, 'https://vm-01.tlt.usu.edu/api/'. $url);
    //     }

    //     curl_setopt($ch, CURLOPT_HTTPHEADER, $this->usuTokenHeader);
    //     curl_setopt($ch, CURLOPT_POST, TRUE);
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); // ask for results to be returned

    //     // Send to remote and return data to caller.
    //     $response = curl_exec($ch);
    //     curl_close($ch);
    //     return $response;
    // }

    // public function curlPut($url, $data)
    // {
    //     $ch = curl_init();

    //     if (strpos($url, $this->domain) !== false) {
    //         curl_setopt($ch, CURLOPT_URL, $url);
    //     } else {
    //         curl_setopt($ch, CURLOPT_URL, 'https://vm-01.tlt.usu.edu/api/'. $url);
    //     }

    //     curl_setopt($ch, CURLOPT_HTTPHEADER, $this->usuTokenHeader);
    //     curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // ask for results to be returned

    //     // Send to remote and return data to caller.
    //     $response = curl_exec($ch);
    //     curl_close($ch);
    //     return $response;
    // }

    public function ucurlDelete($url)
    {
        $ch = curl_init();

        if (strpos($url, $this->domain) !== false) {
            curl_setopt($ch, CURLOPT_URL, $url);
        } else {
            curl_setopt($ch, CURLOPT_URL, 'https://vm-01.tlt.usu.edu/api/'.$url);
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->usuTokenHeader);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // Send to remote and return data to caller.
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    public function ucurlAllGet($url) {

         $apiUrl = 'https://vm-01.tlt.usu.edu/api'.$url;
  
        $curl = curl_init();
        // var_dump($apiUrl);
        curl_setopt($curl, CURLOPT_URL, $apiUrl);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);

        $data = curl_exec($curl);

        curl_close($curl);

       return $data ;
    }


    public function getPreferences()
    {

        $apiUrl = "/preferences";
      
       
        return  $this->ucurlAllGet($apiUrl);
    }
    public function getUsers()
    {

        $apiUrl = "/users";
      
       
        return  $this->ucurlAllGet($apiUrl);
    }

    //  public function getUsers($userID)
    // {

    //     $apiUrl = "/users/".$userID;
      
       
    //     return  $this->ucurlAllGet($apiUrl);
    // }


    protected function httpParseHeaders($raw_headers) {
        $headers = array();
        $key = '';

        foreach(explode("\n", $raw_headers) as $i => $h) {
            $h = explode(':', $h, 2);

            if (isset($h[1])) {

                if (!isset($headers[$h[0]])){
                    $headers[$h[0]] = trim($h[1]);
                } elseif (is_array($headers[$h[0]])) {
                    $headers[$h[0]] = array_merge($headers[$h[0]], array(trim($h[1])));
                } else {
                    $headers[$h[0]] = array_merge(array($headers[$h[0]]), array(trim($h[1])));
                }

                $key = $h[0];
            } else {
                if (substr($h[0], 0, 1) == "\t")
                    $headers[$key] .= "\r\n\t".trim($h[0]);
                elseif (!$key)
                    $headers[0] = trim($h[0]);
            }
        }
        return $headers;
    }

}