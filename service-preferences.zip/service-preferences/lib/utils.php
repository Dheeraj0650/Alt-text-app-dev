<?php

class ServicePreferencesUtils
{
    public static $canvas_oauth_id;
    public static $canvas_oauth_key;
    public static $canvas_domain;
    public static $canvas_consumer_key;
    public static $canvas_secret_key;
    public static $oauth_redirect_url;

    public static $canvas_base_url;
    public static $canvas_user_id;
    public static $canvas_api_key;

    private $encryption_key = 'fJQ94gwHQSi8GHmsRY0bPX4uvFXGTqfi';
    public static $version = '1.1.2';
    public static $tmp_dir = '../tmp/';

    private static $instance;

    public static function instance()
    {
        if (!isset(self::$instance)) {
            self::$instance = new ServicePreferencesUtils();
        }
       
        return self::$instance;
    }

    public function setup()
    {

        global $oauth_redirect_url;
        
        
        // Testing for Safari, as we need to redirect for cookies to work.
        $this->testSafari();
        

        $inst = $this->getInstitution();

        if (empty($inst)) {
            $this->clearSession();
            self::instance()->exitWithError('Institution not found in ServicePreferences database.');
        }

        self::$canvas_oauth_id = $inst['developer_id'];
        self::$canvas_oauth_key = $inst['developer_key'];
        self::$canvas_consumer_key = $inst['consumer_key'];
        self::$canvas_secret_key = $inst['shared_secret'];
        self::$canvas_domain = $this->getCanvasDomain();
        self::$oauth_redirect_url = $oauth_redirect_url;
        self::$canvas_base_url = rtrim("https://" . self::$canvas_domain, '/');
        self::$canvas_user_id = $this->getCanvasUserId();

        $GLOBALS['domain'] = self::$canvas_domain;
        
        if (empty($GLOBALS['tmp_dir'])) {
            $GLOBALS['tmp_dir'] = self::$tmp_dir;
        }

        
        $api_key = $this->getValidRefreshedApiKey();

      
        if (!empty($api_key)) {
            self::$canvas_api_key = $api_key;
            $GLOBALS['tokenHeader'] = array("Authorization: Bearer " . $api_key);
        }

        if (ENV_TYPE == 'dev') {
            self::$version = microtime(TRUE);
        }

        // print_r(self::$canvas_oauth_id);
        // print_r($api_key);
        // exit();
    }

    public function exitWithError($error)
    {
        $post = filter_input_array(INPUT_POST);
        \CidiLabs\Log::insert($error, 'utils::exitWithError', 'error', 'high', $post);

        echo $error;
        error_log($error);
        exit();
    }

    public function getLocalApiKey()
    {
        $user = $this->getUser();
        if (empty($user['api_key'])) {
            return FALSE;
        }

        return $this->decryptData($user['api_key']);
    }

    public function getValidRefreshedApiKey()
    {
        // check our db for an existing api key
        $api_key = $this->getLocalApiKey();
        if (!empty($api_key)) {
            if ($this->validateApiKey($api_key)) {
        
                return $api_key;
            }
            if ($api_key = $this->refreshApiKey()) {
                return $api_key;
            }
        }

        return false;
    }

    public function validateApiKey($api_key)
    {
       
        if (empty($api_key)) {
            return false;
        }
        

        $token_header = array("Authorization: Bearer " . $api_key);
        $user_id = $this->getCanvasUserId();
        $url = self::$canvas_base_url . "/api/v1/users/{$user_id}/profile";
        $canvasApi = new \ServicePreferences\CanvasApi(self::$canvas_domain, $token_header);
        $result = $canvasApi->curlGet($url);
        // print_r($result);
        // exit();

        return isset($result->id);
    }

    public function getRefreshToken()
    {
        $user = $this->getUser();

        if (!empty($user['refresh_token'])) {
            return $user['refresh_token'];
        }

        return false;
    }

    public function refreshApiKey()
    {
        $refresh_token = $this->getRefreshToken();

        if (!$refresh_token) {
            return false;
        }

        $post_data = [
            'grant_type'    => 'refresh_token',
            'client_id'     => self::$canvas_oauth_id,
            'redirect_uri'  => self::$oauth_redirect_url,
            'client_secret' => self::$canvas_oauth_key,
            'refresh_token' => $refresh_token,
        ];

        $result = $this->curlOauthToken(self::$canvas_base_url, $post_data);

        // update the token in the database
        if (isset($result->access_token) && $this->validateApiKey($result->access_token)) {
            $encrypted_token = $this->encryptData($result->access_token);
            $this->updateUser(['api_key' => $encrypted_token]);

            return $result->access_token;
        }

        return false;
    }

    public function authorizeNewApiKey($base_url, $code)
    {
        $post_data = [
            'grant_type'    => 'authorization_code',
            'client_id'     => self::$canvas_oauth_id,
            'redirect_uri'  => self::$oauth_redirect_url,
            'client_secret' => self::$canvas_oauth_key,
            'code'          => $code,
        ];

        return $this->curlOauthToken($base_url, $post_data);
    }

    public function createOrUpdateUser($api_key, $refresh_token)
    {

        $user = $this->getUser();

        $encrypted_key = $this->encryptData($api_key);
        

        if (empty($user)) {
            $this->insertUser($encrypted_key, $refresh_token);
        }
        else {
            $this->updateUser([
                'api_key' => $encrypted_key,
                'refresh_token' => $refresh_token,
            ]);
        }
    }

    public function verifyBasicLTILaunch()
    {
        require_once(__DIR__.'/ims-blti/blti.php');
        $context = new BLTI(self::$canvas_secret_key, false, false);

        return isset($context->valid) && $context->valid;
    }

    protected function curlOauthToken($base_url, $post_data)
    {
        $ch = curl_init("{$base_url}/login/oauth2/token");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        // Ignore SSL certificates when specified in local config
        // (E.g. when Canvas instance does not have trusted SSL certificates)
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        $result = curl_exec($ch);
        curl_close($ch);

        return json_decode($result);
    }

    /**
     * Returns database row for user.
     *
     * @return array
     */
    public function getUser()
    {
        $user_id = $this->getCanvasUserId();
        $canvas_domain = $this->getCanvasDomain();

        if (empty($user_id) || empty($canvas_domain)) {
            self::instance()->exitWithError('Missing user credentials.');
        }

        return DB::queryFirstRow("SELECT * FROM sp_users WHERE canvas_user_id = %s AND canvas_domain = %s", $user_id, $canvas_domain);
    }

    public function updateUser($values)
    {
        $user = $this->getUser();

        $values += $user;

        DB::update('sp_users', $values, 'canvas_user_id=%s AND canvas_domain=%s', $user['canvas_user_id'], $user['canvas_domain']);
    }

    public function insertUser($api_key, $refresh_token)
    {
        $values = [
            'canvas_domain' => $this->getCanvasDomain(),
            'canvas_user_id' => $this->getCanvasUserId(),
            'api_key' => $api_key,
            'refresh_token' => $refresh_token,
            'created' => time(),
        ];

        DB::insert('sp_users', $values);
    }

    public function getInstitution()
    {
        
        $canvas_domain = $this->getCanvasDomain();
        $canvas_domain = str_replace(['.beta.', '.test.'], '.', $canvas_domain);
        $oauth_consumer_key = $this->getOauthConsumerKey();
     
        if (empty($canvas_domain) || empty($oauth_consumer_key)) {
            self::instance()->exitWithError('Missing institution credentials.');
        }
        $result = DB::queryFirstRow("SELECT * FROM sp_institutions WHERE canvas_domain = %s AND consumer_key = %s", $canvas_domain, $oauth_consumer_key);
     
       // var_dump($result);
       // var_dump($oauth_consumer_key);
       // exit();

        if (!$result) {
            $result = DB::queryFirstRow("SELECT * FROM sp_institutions WHERE vanity_url = %s AND consumer_key = %s", $canvas_domain, $oauth_consumer_key);
        }
         
      
        return $result;
    }

    public function getInstitutionData($key = '', $default = '')
    {

        $inst = $this->getInstitution();
        $meta = \json_decode($inst['metadata'], TRUE);

        if (empty($key)) {
            return $meta;
        }

        return (isset($meta[$key]) ? $meta[$key] : $default);
    }

    public function getCanvasDomain()
    {
        $post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
        if (!empty(ServicePreferencesUtils::$canvas_domain)) {
            return ServicePreferencesUtils::$canvas_domain;
        }
        elseif (!empty($_SESSION['canvasDomain'])) {
            return $_SESSION['canvasDomain'];
        }
        elseif (ENV_TYPE == 'dev') {
            return 'usu.instructure.com';
        }
        else {
            if (!empty($post['custom_canvas_api_domain'])) {
                
                return $post['custom_canvas_api_domain'];
            }
        }

        \CidiLabs\Log::insert('No canvas domain found.', 'utils::getCanvasDomain', 'error', 'high', $post);

        return FALSE;
    }

    public function getCanvasUserId()
    {
        if (!empty(ServicePreferencesUtils::$canvas_user_id)) {
            return ServicePreferencesUtils::$canvas_user_id;
        }
        elseif (!empty($_SESSION['canvasUserID'])) {
            return $_SESSION['canvasUserID'];
        }
        elseif (ENV_TYPE == 'dev') {
            return '1558293';
        }
        else {
            $canvas_user_id = filter_input(INPUT_POST, 'custom_canvas_user_id', FILTER_SANITIZE_NUMBER_INT);

            if (!empty($canvas_user_id)) {
                return $canvas_user_id;
            }
        }

        return FALSE;
    }

    public function getOauthConsumerKey()
    {   
       //  var_dump($_SESSION['oauthConsumerKey']);
       // exit();
        if (!empty($_SESSION['oauthConsumerKey'])) {
            return $_SESSION['oauthConsumerKey'];
        } elseif (ENV_TYPE === 'dev') {
            return 'service.preferences';
        }

        return filter_input(INPUT_POST, 'oauth_consumer_key');
    }

    public function downloadFiles($post)
    {
        $files = $post['files'];
        $course_id = $post['course_id'];

        $this->removeFiles();

        $file_dest = $GLOBALS['tmp_dir'] . self::$canvas_domain . '/' . $course_id . '/';
        if (!is_dir($file_dest)) {
            mkdir($file_dest, 0777, TRUE);
        }

        foreach ($files as $filename => $url) {
            $filename = urldecode($filename);
            $new_filename = $file_dest . $filename;

            $file = fopen ($url, 'rb');
            if ($file) {
                $newf = fopen ($new_filename, 'wb');
                if ($newf) {
                    while(!feof($file)) {
                        fwrite($newf, fread($file, 1024 * 8), 1024 * 8);
                    }
                }
                fclose($file);
                fclose($newf);
            }
        }

        print $file_dest;
    }

    public function archiveFiles($get)
    {
        $course_id = $get['course_id'];
        $dir_path = $GLOBALS['tmp_dir'] . self::$canvas_domain . '/' . $course_id;
        $zip_file = $dir_path . '-' . date('Ymd-His') . '.zip';

        $zip = new ZipArchive();
        if ($zip->open($zip_file, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
            if ($handle = opendir($dir_path)) {
                while (false !== ($entry = readdir($handle))) {
                    if (strpos($entry, '.') !== 0 && !is_dir($dir_path . '/' . $entry)) {
                        $zip->addFile($dir_path . '/' . $entry, $entry);
                    }
                }
                closedir($handle);
            }

            $zip->close();

            if (file_exists($zip_file)) {
                $this->sendFile($zip_file);
            }
        }
    }

    public function sendFile($file)
    {
        if(file_exists($file)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($file) . '"');
            header('Content-Transfer-Encoding: binary');
            header('Expires: 0');
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file)); //Remove

            readfile($file);
            exit;
        }
    }

    public function removeFiles()
    {
        $dir_path = $GLOBALS['tmp_dir'];
        ignore_user_abort(TRUE);

        if (!empty($dir_path)) {
            foreach (glob("$dir_path*") as $filepath) {
                $updated = filemtime($filepath);

                if ($updated < (time() - 60)) {
                    $this->deleteTree($filepath);
                }
            }
        }
    }

    public function deleteTree($dir) {
        $files = array_diff(scandir($dir), array('.','..'));

        foreach ($files as $file) {
            (is_dir("$dir/$file")) ? $this->deleteTree("$dir/$file") : unlink("$dir/$file");
        }

        return rmdir($dir);
    }

    public function encryptData($data)
    {
        $nonce = openssl_random_pseudo_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        // if  (function_exists("sodium_crypto_secretbox")){
        //     print("here");
        //     exit();
        // }
    
        $encrypted_data = sodium_crypto_secretbox($data, $nonce, $this->encryption_key);
        // print_r("meme");
        // exit();
        return base64_encode($nonce . $encrypted_data);
    }

    public function decryptData($data)
    {
        $encrypted_data = base64_decode($data);

        //  Decrypt the token.
        $nonce = mb_substr($encrypted_data, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES, '8bit');
        $encrypted_text = mb_substr($encrypted_data, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES, NULL, '8bit');

        return sodium_crypto_secretbox_open($encrypted_text, $nonce, $this->encryption_key);
    }

    public function clearSession()
    {
        unset($_SESSION['courseID']);
        unset($_SESSION['canvasDomain']);
        unset($_SESSION['canvasUserID']);
        unset($_SESSION['tool_url']);
    }

    public function testSafari()
    {
        if (isset($_SERVER['HTTP_USER_AGENT'])) {
            $chrome_position = stripos($_SERVER['HTTP_USER_AGENT'], 'chrome');
            $safari_position = stripos($_SERVER['HTTP_USER_AGENT'], 'safari');

            if (false !== $safari_position && false === $chrome_position) {
                if (count($_COOKIE) === 0) {
                    header('Location: safari_fix.php');
                    exit;
                }
            }
        }
    }

    public function getScopes($asArray = false)
    {
        $scopes = [
            'url:GET|/api/v1/users/:user_id/files',
            'url:GET|/api/v1/users/:user_id/folders',
            'url:GET|/api/v1/users/:user_id/profile',
            'url:GET|/api/v1/courses/:id',
            'url:GET|/api/v1/courses/:course_id/assignments',
            'url:GET|/api/v1/courses/:course_id/discussion_topics',
            'url:GET|/api/v1/courses/:course_id/discussion_topics/:topic_id/entries',
            'url:GET|/api/v1/courses/:course_id/modules',
            'url:GET|/api/v1/courses/:course_id/pages',
            'url:GET|/api/v1/courses/:course_id/pages/:url',
            'url:GET|/api/v1/courses/:course_id/quizzes',
            'url:GET|/api/v1/courses/:course_id/quizzes/:quiz_id/questions',
            'url:GET|/api/v1/courses/:course_id/folders',
            'url:GET|/api/v1/courses/:course_id/files',
            'url:DELETE|/api/v1/courses/:course_id/assignments/:id',
            'url:DELETE|/api/v1/courses/:course_id/discussion_topics/:topic_id',
            'url:DELETE|/api/v1/courses/:course_id/modules/:id',
            'url:DELETE|/api/v1/courses/:course_id/pages/:url',
            'url:DELETE|/api/v1/courses/:course_id/quizzes/:id',
            'url:DELETE|/api/v1/files/:id',
            'url:DELETE|/api/v1/folders/:id',
            'url:PUT|/api/v1/files/:id',
            'url:PUT|/api/v1/folders/:id',
            'url:PUT|/api/v1/courses/:id',
            'url:PUT|/api/v1/courses/:course_id/assignments/:id',
            'url:PUT|/api/v1/courses/:course_id/discussion_topics/:topic_id',
            'url:PUT|/api/v1/courses/:course_id/modules/:id',
            'url:PUT|/api/v1/courses/:course_id/pages/:url',
            'url:PUT|/api/v1/courses/:course_id/quizzes/:id',
        ];

        if ($asArray) {
            return $scopes;
        }

        return implode(' ', $scopes);
    }
}
