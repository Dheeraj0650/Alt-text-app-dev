<?php

require_once '../config/config.php';

$get = filter_input_array(INPUT_GET, FILTER_SANITIZE_STRING);
$post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
$request = $get ? $get : $post;

if ( !isset($request['task'])) {
    ServicePreferencesUtils::instance()->exitWithError('Information missing from Action API.');
}

$Preferences = new \ServicePreferences\Preferences();

switch($request['task']) {

    case 'retrievePreferences':

        print $Preferences->retrievePreferences();

        break;

    case 'retrieveUsers':
        
      
        print $Preferences->retrieveUsers($request['userID']);

        break;
    case 'retrieveMyPreferences':
        
      
        print $Preferences->retrieveMyPreferences();

        break;  
    case 'updateMyPreferences':
        
        print $Preferences->updateMyPreferences($request['fieldName'], $request['fieldValue']);

        break;
    case 'updateMyInterests':

        print $Preferences->updateMyInterests($request['fieldName'], $request['fieldValue']);
        break;


    default:
        ServicePreferencesUtils::instance()->exitWithError('Task missing from Action API.');
}
