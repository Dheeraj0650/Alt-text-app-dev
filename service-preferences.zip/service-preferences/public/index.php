<?php

// print("meme");
// var_dump($_POST);
require_once('../config/config.php');


if (ENV_TYPE == 'prod') {
    /**
     * REMOVE THIS AFTER DEVELOPMENT IS COMPLETE!!!!!
     */
    $_POST = [
        'oauth_consumer_key' => 'service.preferences',
        'oauth_signature_method' => 'HMAC-SHA1',
        'oauth_timestamp' => '1550077942',
        'oauth_nonce' => '1233213232123123123',
        'oauth_version' => '1.0',
        'custom_canvas_user_id' => '1558293',
        'custom_canvas_course_id' => '391132',
        'custom_canvas_api_domain' => 'usu.instructure.com',
        'lti_message_type' => 'basic-lti-launch-request',
        'lti_version' => 'LTI-1p0',
        'resource_link_id' => '123123123123123123123',
        'context_label' => 'ServicePreferences',
        'context_title' => 'ServicePreferences Tool',
    ];
    $_REQUEST = $post_input = $_POST;
}
else {
    $post_input = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
    $post_input['custom_canvas_user_id'] = filter_input(INPUT_POST, 'custom_canvas_user_id', FILTER_SANITIZE_NUMBER_INT);
    // $post_input['custom_canvas_course_id'] = filter_input(INPUT_POST, 'custom_canvas_course_id', FILTER_SANITIZE_NUMBER_INT);
}

if (isset($post_input['custom_canvas_user_id'])){
    // $_SESSION['courseID'] = $post_input['custom_canvas_course_id'];
    $_SESSION['canvasDomain'] = $post_input["custom_canvas_api_domain"];
    $_SESSION['canvasUserID'] = $post_input['custom_canvas_user_id'];
    $_SESSION['oauthConsumerKey'] = $post_input['oauth_consumer_key'];

    $_SESSION['fullName'] = $_POST['lis_person_name_full'];
    $_SESSION['domain'] = $_POST['custom_canvas_api_domain'];
    $_SESSION['userID'] = $_POST['custom_canvas_user_id'];
    $_SESSION['login_id'] = $_POST['custom_canvas_user_login_id'];
    $_SESSION['email_primary'] = $_POST['lis_person_contact_email_primary'];
    $_SESSION['name_given'] = $_POST['lis_person_name_given'];
    $_SESSION['user_image'] = $_POST['user_image'];
    $_SESSION['canvasURL'] = 'https://'.$_SESSION['domain'];
    $_SESSION['courseName'] = $_POST['context_title'];
    $_SESSION['role'] = $_POST['roles'];
    $_SESSION['roleName'] = $_POST['lis_person_name_full'];
    $_SESSION['zoomdomain'] = 'api.zoom.us';
}

// elseif (!isset($_SESSION['courseID']) || !isset($_SESSION['canvasDomain'])) {
elseif (!isset($_SESSION['canvasUserID']) || !isset($_SESSION['canvasDomain'])) {
    ServicePreferencesUtils::instance()->exitWithError("Missing valid LTI credentials");
}

// verify we have the variables we need from the LTI launch
// $expect = ['oauth_consumer_key', 'custom_canvas_api_domain', 'custom_canvas_user_id', 'custom_canvas_course_id'];
$expect = ['oauth_consumer_key', 'custom_canvas_api_domain', 'custom_canvas_user_id'];
foreach ($expect as $key) {
    if (empty($post_input[$key])) {
        ServicePreferencesUtils::instance()->exitWithError("Missing LTI launch information. Please ensure that your instance of ServicePreferences is installed to Canvas correctly. Missing: {$key}");
    }
}

// verify LTI launch
if (!ServicePreferencesUtils::instance()->verifyBasicLTILaunch() && (ENV_TYPE !== 'dev')) {
    ServicePreferencesUtils::instance()->exitWithError('LTI/Oauth verification problem, please ensure that your instance of ServicePreferences is configured correctly.');
}

// role base redirect
// var_dump($_SESSION['role']);
// exit();
// if (strpos($_SESSION['role'] , 'Learner') !== false ) {
//     $toolUrl = "care-team.php";
// } else {
//     $toolUrl = "tool.php";
    
// }


// get scopes
$scope_str = ServicePreferencesUtils::instance()->getScopes();
$redirect_to = (!empty(ServicePreferencesUtils::$canvas_api_key)) ? 
    "build/index.html"  : 
    ServicePreferencesUtils::$canvas_base_url . "/login/oauth2/auth/?client_id=" . ServicePreferencesUtils::$canvas_oauth_id . 
    "&response_type=code&redirect_uri=" . ServicePreferencesUtils::$oauth_redirect_url . "&scope=" . $scope_str;
       

// print_r($redirect_to);
// // 
// exit();
header("Location: {$redirect_to}");
    