var FlagCourse = {
    courseId: null,
    data: null,

    init: function() {


        this.retrieveCourses();
        this.retrieveDepartement();
        this.retrieveTerms();


    },


    retrieveTerms: function() {
        $.post("action.php", {
            task: "retrieveAllTerms",

        }).done(function(data_str) {
            var data = JSON.parse(data_str);
            console.log(data)
            $.each(data, function(index, value) {
                $(".terms").append(`<option value="${value.sis_term_id}" data-name="${value.name}">${value.name}</option>`);
            });
        });


    },
    retrieveDepartement: function() {
        $.post("action.php", {
            task: "retrieveDepartement",

        }).done(function(data_str) {
            var data = JSON.parse(data_str);
            $.each(data, function(index, value) {
                $(".department").append(`<option value="${value.dept_id}" data-name="${value.dept_name}">${value.dept_name}</option>`);
            });
        });


    },
    retrieveCourses: function() {
        // $('#data-filter .department').change(function() {
        $('.search-course').unbind('click').click(function(event) {
            var table = $('#course-list-table').DataTable();
            table.destroy();
            $("#course-list-table tbody").html('');
            var term_id = $(".terms option:selected").val();
            var search_term = $(".course-search-name").val();
         
            $.post("action.php", {
                task: "retrieveTrackedCourses",
                term_id: term_id,
                search_term: search_term

            }).done(function(data_str) {
                // console.log(data_str)
                var data = JSON.parse(data_str);
                $.each(data, function(index, value) {
                    var status = "Not Flagged";
                    var section_code = "NO Section";
                    var sis_course_id = (value.sis_course_id).trim();
                    if (sis_course_id.indexOf(".")!==-1) {
                        var crn_array = sis_course_id.split('.');
                        var crn = crn_array[0];
                    } else {

                        var crn = (sis_course_id).substring(0,sis_course_id.length -6);
                    }
                    // console.log(value)
                    if (value.status !== null) {
                        if (value.status == 0) {
                            status = '<div  class="bg-success" style="font-size: 20px;font-weight: 700; text-align: center; color:#fff;">Green</div>';
                            status_flag = '<div  class="bg-success" style="font-size: 20px;font-weight: 700; text-align: center; color:#fff;">Green</div>';
                        }
                        if (value.status == 1) {

                            status = '<div style="font-size: 20px;font-weight: 700; text-align: center; background-color:#ff9800;">Orange</div>';
                            status_flag = '<div class="bg-warning" style="font-size: 20px;font-weight: 700; text-align: center; background-color:#ff9800;">Orange</div>';
                        }
                        if (value.status == 2) {

                            status = '<div class="bg-danger" style="font-size: 20px;font-weight: 700; text-align: center; color:#fff;">Red</div>';
                            status_flag = '<div class="bg-danger" style="font-size: 20px;font-weight: 700; text-align: center; color:#fff;">Red</div>';
                        }

                    }
                    if (value.section_code!==null) {
                        section_code = value.section_code;
                        
                    }

                    $("#course-list-table tbody").append(`
                        <tr  data-course="${value.course_id}" data-termId=${value.term_id} data-std="${value.total_students}" data-crn="${crn}">
                            <td class="course_name"><a href="https://usu.instructure.com/courses/${value.course_id}" target="_blank">${value.course_name}</a></td>
                            <td class="section_code">${section_code}</td>
                            <td class="status">${status}</td>
                            <td class="delivery_method">${value.delivery_method}</td>
                            <td class="dept_name">${value.dept_name}</td>
                            <td class="campus_name">${value.campus_name}</td>
                           
                            <td>
                                <div>
                                    <button type="button" class="teacher-info btn btn-sm btn-outline-secondary">Info</button>
                                    <button type="button" class="students-seat btn btn-sm btn-outline-secondary">Seat</button>
                                </div>
                            </td>
                        </tr>
                    `);
                });
                FlagCourse.retrieveTeachers();
                FlagCourse.retrieveSeatChart();
                var table = $('#course-list-table').DataTable();
            });
        });



    },
     surroundingSeat: function(crn) {
        $('.seat-surrounding').unbind('click').click(function(event) {
            
            $("#surrounding-list-table tbody").html('')
            $('#surrounding-seat-modal').modal('show');
            $('.data-loading').html('<i class="fa fa-spinner fa-spin" style="font-size:36px;"></i>');

            var student_name =  $(this).parents('tr').find('.student_name').text();
            var termCode  = 202220;
            var rowLetter = $(this).parents('tr').data('row');
            var seatNumber = $(this).parents('tr').data('seat');
            var radius = 2;
            // var crn= $(this).parents('tr').data('crn');
            $('#surrounding-seat-modal .modal-title').html(student_name + " Surrounding Seats");

            $.post("action.php", {
                task: "retrieveStudentSurrroundingSeat",
                crn: crn,
                termCode: termCode,
                rowLetter: rowLetter,
                seatNumber: seatNumber,
                radius: radius,
            }).done(function(seat_data_str) {
                var seat_data = JSON.parse(seat_data_str);
                if (seat_data.status == 404) {

                    $('.data-loading').html(`<div class="alert alert-success">No surrounding seat found!</div>`);

                } else {

                    $.each(seat_data, function(index, val) {
                        var username =  val.username;
                        $.post("action.php", {
                            task: "retrieveContact",
                            username: username
                        }).done(function(data_str) {
                            var data = JSON.parse(data_str);
                            if (data.length > 0) {
                                $("#surrounding-list-table tbody").append(`
                                    <tr data-login="${username}">
                                        <td>${val.studentName}</td>
                                        <td>${username}</td>
                                        <td>${data[0].areaCode} ${data[0].number}</td>
                                        <td><a href="mailto:${username.toLowerCase()}@usu.edu">${username.toLowerCase()}@usu.edu</a></td>
                                        <td>${val.rowLetter}${val.seatNumber}</td>
                                        <td>${val.activityDate}</td>
                                    </tr>
                                `);

                            }
                            $('.data-loading').html(``);
                            
                        });
                    });
                }
            });
        });
    },
        retrieveTeachers: function() {
        $('.teacher-info').unbind('click').click(function(event) {
            var course_id = $(this).parents('tr').data("course");
            var course_name = $(this).parents('tr').find('.course_name').text();
            var course_status = $(this).parents('tr').find('.status').data("status");
            var students = $(this).parents('tr').data("std");

            $('.publish-status').html('<i class="fa fa-spinner" style="font-size:36px; fa-spin"></i>');
            $('#teacher-info').html('');
            $("#status-history-table tbody").html('');
            $('#info-modal').modal('show');
            $('#info-modal .modal-title').html(course_name + " Info");
            $('.total-student').html(students);

            // $.post("action.php", {
            //     task: "retrieveTeachers",
            //     course_id: course_id,
            // }).done(function(data_str) {
            //     var data = JSON.parse(data_str);
            //     $.each(data, function(index, value) {

            //         $('#teacher-info').append(`<li><a href="${value.html_url}" target="_blank">${value.user.name} <i class="fas fa-external-link-alt"></i><a/></li `);
            //         // console.log(value)
            //     });
            // });
            FlagCourse.sendNotification(course_status, course_name);
            $.post("action.php", {
                task: "retrieveCourseDetail",
                course_id: course_id,
            }).done(function(data_str) {
                var data = JSON.parse(data_str);
                var teachers = data.teachers;
                 $.each(teachers, function(index, value) {
                    $('#teacher-info').append(`<li><a href="${value.html_url}" target="_blank">${value.display_name} <i class="fas fa-external-link-alt"></i><a/></li `);
                });
                    // console.log(data)
                    if (data.workflow_state === "available") {
                        $('.publish-status').html('This course is Available (Published)');
                    } 
                     if (data.workflow_state === "unpublished") {
                        $('.publish-status').html('This course is Unpublished');
                        $('.send_notification').attr("disabled","disabled");
                    } 
                     if (data.workflow_state === "deleted") {
                        $('.publish-status').html('This course has been deleted');
                        $('.send_notification').attr("disabled","disabled");
                    } 
                     if (data.workflow_state === "completed") {
                        $('.publish-status').html('This course has been completed');
                        $('.send_notification').attr("disabled","disabled");
                    } 
            });

            $.post("action.php", {
                task: "retrieveStatusHistory",
                course_id: course_id,
            }).done(function(data_str) {
                var data = JSON.parse(data_str);
                // console.log(data)
                $.each(data, function(index, value) {
                    if (value.status == 0) {
                        status = '<div  class="bg-success" style="font-size: 20px;font-weight: 700; text-align: center; color:#fff;">Green</div>';

                    }
                    if (value.status == 1) {

                        status = '<div class="bg-warning" style="font-size: 20px;font-weight: 700; text-align: center; background-color:#ff9800;">Orange</div>';
                    }
                    if (value.status == 2) {

                        status = '<div class="bg-danger" style="font-size: 20px;font-weight: 700; text-align: center; color:#fff;">Red</div>';
                    }
                    $("#status-history-table tbody").append(`
                        <tr>
                            <td class="course_name">${value.flaged_at}</td>
                            <td >${status}</td>
                          
                        </tr>
                    `);
                });
            });
        });


    },

    sendNotification: function(status, course_name) {
        $('.send_notification').unbind('click').click(function(event) {
            $.confirm({
                icon: 'fas fa-exclamation-triangle',
                title: 'Delete',
                content: `Do you want to send Notification to the class?`,
                type: 'orange',
                animation: 'zoom',
                closeAnimation: 'scale',
                buttons: {
                    confirm: function() {
                        var title = `Covid Classroom Status`;
                        var course_id = "391132";
                        var message = "";

                        if (status == 0) {
                             message = `The Covid Classroom Status for ${course_name} has has been updated to Green. 
                             You can learn more about the Green classroom status and action required on your part at usu.edu/covid-19/students/classroom-exposure/
                        `;

                        }
                        if (status == 1) {

                             message = `The Covid Classroom Status for ${course_name}  has been updated to Orange. 
                             You can learn more about the Orange classroom status and action required on your part at usu.edu/covid-19/students/classroom-exposure/ 
                            `;
                        }
                        if (status == 2) {

                             message = `The Covid Classroom Status for ${course_name} has been updated to RED/Remote Delivery.  
                            All students will attend this class via Zoom until USU Case Containment has completed the classroom exposure investigation.  
                            During the investigative process, Case Containment Investigators will continue to contact those exposed. 
                            You can learn more about the RED classroom status and action required on your part at  
                            https://www.usu.edu/covid-19/students/classroom-exposure/. 
                            Your instructor will provide the Zoom link and further course-related instructions through Canvas or an email.
                            If you are vaccinated, CDC guidance indicates; People who are fully vaccinated do NOT need to quarantine after contact with someone who
                            had COVID-19 unless they have symptoms.
                            However, fully vaccinated people should get tested 3-5 days after their exposure, even if they don’t have symptoms and wear
                            a mask indoors in public for 14 days following exposure or until their test result is negative.`;
                        }


                        $.post("action.php", {
                            task: "NewAnnouncement",
                            course_id: course_id,
                            title: title,
                            message: message,

                        }).done(function(data_str) {
                            var data = JSON.parse(data_str);
                            // console.log(data)
                        });

                    },
                    cancel: function() {
                        // $.alert('Canceled!');
                    }
                }
            });
        });

    },
    
    retrieveSeatChart: function() {
        $('.students-seat').unbind('click').click(function(event) {
            var course_id = $(this).parents('tr').data("course");
            var crn = $(this).parents('tr').data("crn");
            var course_name = $(this).parents('tr').find('.course_name').text();
            var table = $('#seating-list-table').DataTable();

            table.destroy();

            $("#seating-list-table tbody").html('');
            $('#seating-modal').modal('show');
            $('#seating-modal .modal-title').html(course_name + " Seat Info");
            $(".seat-data-loading").html('<div class="alert alert-success">Loading Course Roster <i class="fa fa-spinner fa-spin " style="font-size:36px;"></i></div>');

            // FlagCourse.retrieveSeatDate(course_id); 

            // $.post("action.php", {
            //     task: "retrieveCourseStudents",
            //     course_id: course_id,
            // }).done(function(data_str) {

            // });
            $.post("action.php", {
                task: "studentlList",
                course_id: course_id,
            }).done(function(data_str) {
                var data = JSON.parse(data_str);
                // console.log(data)
                $("#seating-list-table tbody").html('');
                $.each(data, function(index, value) {
                    $("#seating-list-table tbody").append(`
                        <tr data-login="${value.user.login_id}">
                            <td class="student_name">${value.user.short_name}</td>
                            <td>${value.user.login_id}</td>
                            <td class="seat_number"></td>
                            <td class="insert_date"></td>
                            <td><button type="button" class="seat-surrounding btn btn-sm btn-secondary">Surrounding</button></td>
                        </tr>
                    `);
                });
                $("#seating-list-table tbody tr").each(function(){
                    var tr = $(this);
                    var login_id = $(this).data('login');
          
                    $.post("action.php", {
                        task: "retrievseStudentSeat",
                        termCode: 202220,
                        username: login_id,
                        crn: 46546,
                    }).done(function(login_data_str) {
                        var login_data = JSON.parse(login_data_str);
                        // console.log(login_data);
                        var seat_history = $('<div></div>');
                        if (login_data.length > 0) {
                            tr.find('.seat_number').append(`${login_data[0].rowLetter}${login_data[0].seatNumber}`);
                            $.each(login_data, function(index, val) {
                                 $(seat_history).append('<div>'+val.activityDate+'</div><div>'+val.rowLetter+''+ val.seatNumber+'</div>');
                            });
                            tr.attr('data-row',login_data[0].rowLetter).attr('data-seat',login_data[0].seatNumber);
                            // console.log($(seat_history).html());

                            tr.find('.insert_date').append(`<a href="#" title="Seating History" data-toggle="popover" data-html="true" data-trigger="hover" data-content="<div class='seat_history'>${$(seat_history).html()}</div>">${login_data[0].activityDate} <i class="fas fa-angle-double-right"></i></a>`);
                            // $('.seat-history').attr('data-content', $(seat_history));
                        }
                        $('[data-toggle="popover"]').popover();
                    });
                });
                var table = $('#seating-list-table').DataTable({
                    pageLength: 25,
                    dom: 'Bfrtip',
                    buttons: [{
                            title: 'Student Seat Records',
                            text: 'Download CSV',
                            extend: 'excelHtml5',

                        },

                    ],
                    lengthMenu: [
                        [50, 25, 50, -1],
                        [50, 25, 50, "All"]
                    ],
                });

                FlagCourse.surroundingSeat(crn);
                 $(".seat-data-loading").html('');
            });

        });

        // <td class="course_name">${value.short_name}</td>
        // <td>${value.login_id}</td>
        // <td>${course_name}</td>
        // <td>${value.course_crn}</td>
        // <td>${value.row_letter}</td>
        // <td>${value.seat_number}</td>
        // <td>${value.row_letter} ${value.seat_number}</td>
        // <td>${value.insert_date}</td>

    },




};

$(document).ready(function() {
    "use strict";
    // $('table').DataTable();
    FlagCourse.init();
});
