var FlagCourse = {
    courseId: null,
    data: null,

    init: function() {


        this.retrieveTerms();
        this.retrieveCourses();
        this.retrieveFlagedCourses();

    },


    retrieveTerms: function() {
        $.post("action.php", {
            task: "retrieveAllTerms",

        }).done(function(data_str) {
            var data = JSON.parse(data_str);
            $.each(data, function(index, value) {
                $(".terms").append(`<option value="${value.sis_term_id}" data-name="${value.name}">${value.name}</option>`);
            });
        });


    },

    retrieveCourses: function() {
        // $('#data-filter .department').change(function() {
        $('.search-course').unbind('click').click(function(event) {
            var table = $('#course-list-table').DataTable();
            table.destroy();
            $("#course-list-table tbody").html('');
            var term_id = $(".terms option:selected").val();
            var search_field = $(".course-search-name").val();
            var search_term = search_field.trim();
            var search_type = $("#search-type option:selected").val();
            console.log(search_type)
            console.log(search_term)
            console.log(search_field)
            console.log(term_id)

            $.post("action.php", {
                task: "retrieveTrackedCourses",
                term_id: term_id,
                search_term: search_term,
                search_type: search_type,

            }).done(function(data_str) {
                var data = JSON.parse(data_str);
                $.each(data, function(index, value) {

                    var status = "Not Flagged";
                    var section_code = "NO Section";



                    var sis_course_id = (value.sis_course_id).toString();
                    var new_sis = (sis_course_id).trim();
                    if (new_sis.indexOf(".") !== -1) {
                        var crn_array = new_sis.split('.');
                        var crn = crn_array[0];
                    } else {

                        var crn = (new_sis).substring(0, new_sis.length - 6);
                    }


                    // var sis_course_id = (value.sis_course_id).trim();
                    // if (sis_course_id.indexOf(".") !== -1) {
                    //     var crn_array = sis_course_id.split('.');
                    //     var crn = crn_array[0];
                    // } else {

                    //     var crn = (sis_course_id).substring(0, sis_course_id.length - 6);
                    // }

                    // console.log(value)
                    if (value.status !== null) {
                        if (value.status == 0) {
                            status = '<div  class="bg-success" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Green</div>';
                            status_flag = '<div  class="bg-success" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Green</div>';
                        }
                        if (value.status == 1) {

                            status = '<div style="font-size: 18px;font-weight: 700; text-align: center; background-color:#ff9800;">Orange</div>';
                            status_flag = '<div class="bg-warning" style="font-size: 18px;font-weight: 700; text-align: center; background-color:#ff9800;">Orange</div>';
                        }
                        if (value.status == 2) {

                            status = '<div class="bg-danger" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Red</div>';
                            status_flag = '<div class="bg-danger" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Red</div>';
                        }

                    }
                    if (value.section_code !== null) {
                        section_code = value.section_code;

                    }
                    //  console.log(value.college_id)
                    // console.log(value.college_name)
                    // console.log(value.dept_name)
                    //<td class="section_code">${section_code}</td>

                    $("#course-list-table tbody").append(`
                        <tr data data-course="${value.course_id}" data-term=${value.term_id} data-std="${value.total_students}" data-crn="${crn}">
                            <td class="course_name"><a href="https://usu.instructure.com/courses/${value.course_id}" target="_blank">${value.course_name}</a> <button type="button" class="btn btn-sm btn-light section-list"><i class="fas fa-external-link-alt"></i></button></td>
                            
                            <td class="status">${status}</td>
                            <td class="delivery_method">${value.delivery_method}</td>
                            <td class="dept_name" data-college_name="${value.college_name}" data-college_id="${value.college_id}" data-dept_id="${value.dept_id}">${value.dept_name}</td>
                            <td class="campus_name">${value.campus_name}</td>
                            <td>
                                <div>
                                    <button type="button" class="btn btn-sm btn-success  mr-2 flag-course" data-type="green">Green</button>
                                    <button type="button" class="btn btn-sm btn-warning mr-2 flag-course" style="background-color:#ff9800;"  data-type="yellow">Orange</button>
                                    <button type="button" class="btn btn-sm btn-danger  mr-2 flag-course" data-type="red">Red</button>
                                </div>
                            </td>
                            <td>
                                <div>
                                    <button type="button" class="teacher-info btn btn-sm btn-outline-secondary">Info</button>
                                    <button type="button" class="students-seat btn btn-sm btn-outline-secondary">Seat</button>
                                </div>
                            </td>
                        </tr>
                    `);
                });
                // <button type="button" alt="Teacher Info" data-toggle="modal" data-target="#info-modal" class="btn"><i class="far fa-address-card"></i></button>
                // <button type="button" alt="Students Info" data-toggle="modal" data-target="#info-modal" class="btn"><i class="fas fa-th-list"></i></button>
                FlagCourse.flagCourses();
                FlagCourse.retrieveTeachers();
                FlagCourse.retrieveSeatChart();
                FlagCourse.retrieveCourseSection();
                var table = $('#course-list-table').DataTable();
            });
        });



    },

    retrieveCourseSection: function() {
        $('.section-list').unbind('click').click(function(event) {
            $('.course-section-list').html('');
            $('#sections-modal').modal('show');
            $(".section-data-loading").html('<div class="alert alert-success">Loading Course Sections <i class="fa fa-spinner fa-spin " style="font-size:36px;"></i></div>');

            var tr = $(this);
            var course_id = $(this).parents('tr').data('course');
            var course_name = $(this).parents('tr').find('.course_name a').text();

            $('.section-modal-title').html(course_name + " Sections");
            // retrieve course section and display

            $.post("action.php", {
                task: "retrieveCourseSections",
                course_id: course_id,
            }).done(function(section_str) {
                var section = JSON.parse(section_str);
                console.log(section);
                if (section.sections.length > 0) {
                    $.each(section.sections, function(index, value) {

                        $('.course-section-list').append(`<li class="list-group-item"><a href="https://usu.instructure.com/courses/${course_id}/sections/${value.id}" target="_blank">${value.name}</a></li>`)
                    });
                    $(".section-data-loading").html('');
                } else {
                    $('.course-section-list').html('This course has no section available.');
                    $(".section-data-loading").html('');
                }
                // tr.find('.section_code').html(section.name);
            });
            // $("#course-list-table tbody tr").each(function() { });
        });
    },

    retrieveTeachers: function() {
        $('.teacher-info').unbind('click').click(function(event) {
            var course_id = $(this).parents('tr').data("course");
            var term_id = $(this).parents('tr').data("termId");
            var course_name = $(this).parents('tr').find('.course_name').text();
            var course_status = $(this).parents('tr').find('.status').data("status");
            var students = $(this).parents('tr').data("std");

            $('.publish-status').html('<i class="fa fa-spinner" style="font-size:36px; fa-spin"></i>');
            $('#teacher-info').html('');
            $("#status-history-table tbody").html('');
            $('#info-modal').modal('show');
            $('#info-modal .modal-title').html(course_name + " Info");
            $('.total-student').html(students);


            $.post("action.php", {
                task: "retrieveCourseDetail",
                course_id: course_id,
            }).done(function(data_str) {

                var data = JSON.parse(data_str);
                var teachers = data.teachers;
                // console.log(teachers)
                FlagCourse.sendNotification(course_id, teachers);


                $.each(teachers, function(index, value) {
                    // $('#teacher-info').append(`<li><a href="${value.html_url}" target="_blank">${value.display_name} <i class="fas fa-external-link-alt"></i><a/></li `);
                    $('#teacher-info').append(`<li><a href="https://usu.instructure.com/courses/${course_id}/users/${teachers[0].id}" target="_blank">${value.display_name} <i class="fas fa-external-link-alt"></i><a/></li `);
                });
                // console.log(data)

                if (data.workflow_state === "available") {
                    $('.publish-status').html('This course is Available (Published)');
                }
                if (data.workflow_state === "unpublished") {
                    $('.publish-status').html('This course is Unpublished');
                    $('.send_notification').attr("disabled", "disabled");
                }
                if (data.workflow_state === "deleted") {
                    $('.publish-status').html('This course has been deleted');
                    $('.send_notification').attr("disabled", "disabled");
                }
                if (data.workflow_state === "completed") {
                    $('.publish-status').html('This course has been completed');
                    $('.send_notification').attr("disabled", "disabled");
                }
            });

            $.post("action.php", {
                task: "retrieveStatusHistory",
                course_id: course_id,
            }).done(function(data_str) {
                var data = JSON.parse(data_str);
                // console.log(data)
                $.each(data, function(index, value) {
                    if (value.status == 0) {
                        status = '<div  class="bg-success" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Green</div>';

                    }
                    if (value.status == 1) {

                        status = '<div class="bg-warning" style="font-size: 18px;font-weight: 700; text-align: center; background-color:#ff9800;">Orange</div>';
                    }
                    if (value.status == 2) {

                        status = '<div class="bg-danger" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Red</div>';
                    }
                    $("#status-history-table tbody").append(`
                        <tr>
                            <td class="course_name">${value.flaged_at}</td>
                            <td >${status}</td>
                          
                        </tr>
                    `);
                });
            });
        });


    },


    sendNotification: function(course_id, teachers) {
        $('.send_notification').unbind('click').click(function(event) {

            $.confirm({
                icon: 'fas fa-exclamation-triangle',
                title: 'Confirmation',
                content: `Do you want to send Notification to the class and an email to the intructor(s)?`,
                type: 'orange',
                animation: 'zoom',
                closeAnimation: 'scale',
                draggable: true,
                dragWindowBorder: false,
                buttons: {
                    confirm: function() {

                        $.post("action.php", {

                            task: "retrieveThisCourseFlag",
                            course_id: course_id,

                        }).done(function(data_str) {

                            // console.log(data_str)
                            var data = JSON.parse(data_str);
                            var status = data.status;
                            var course_name = data.course_name;
                            var course_id = data.course_id;
                            var message = "";
                            var title = `Covid Classroom Status`;

                            console.log(status)

                            if (status == 0) {
                                message = `The Covid Classroom Status for ${course_name} has has been updated to Green. 
                                You can learn more about the Green classroom status and action required on your part at usu.edu/covid-19/students/classroom-exposure/
                            `;

                            }

                            if (status == 1) {

                                message = `The Covid Classroom Status for ${course_name}  has been updated to Orange. 
                             You can learn more about the Orange classroom status and action required on your part at usu.edu/covid-19/students/classroom-exposure/ 
                            `;
                            }

                            if (status == 2) {

                                message = `The Covid Classroom Status for ${course_name} has been updated to RED/Remote Delivery.  
                                All students will attend this class via Zoom until USU Case Containment has completed the classroom exposure investigation.  
                                During the investigative process, Case Containment Investigators will continue to contact those exposed. 
                                You can learn more about the RED classroom status and action required on your part at  
                                https://www.usu.edu/covid-19/students/classroom-exposure/. 
                                Your instructor will provide the Zoom link and further course-related instructions through Canvas or an email.
                                If you are vaccinated, CDC guidance indicates; People who are fully vaccinated do NOT need to quarantine after contact with someone who
                                had COVID-19 unless they have symptoms.
                                However, fully vaccinated people should get tested 5-7 days after their exposure, even if they do not have symptoms and wear
                                a mask indoors in public for 14 days following exposure or until their test result is negative.`;


                                $.each(teachers, function(index, value) {
                                    var user_id = value.id;
                                    $.post("action.php", {

                                        task: "userDetail",
                                        user_id: user_id,

                                    }).done(function(user_data) {

                                        var user = JSON.parse(user_data);
                                        $.post("action.php", {

                                            task: "sendEmail",
                                            intructor_email: user.primary_email,
                                            instructor_name: user.name,
                                            course_name: course_name,


                                        });
                                    });

                                });
                            }


                            $.post("action.php", {
                                task: "NewAnnouncement",
                                course_id: course_id,
                                title: title,
                                message: message,

                            }).done(function(data_str) {

                                $('#info-modal').modal('hide');
                                $.alert({
                                    title: 'Success!',
                                    content: 'The notification has been sent!',
                                    type: 'green',
                                    draggable: true,
                                    dragWindowBorder: false,
                                });
                            });
                        });

                    },
                    cancel: function() {
                        // $.alert('Canceled!');
                    }
                }
            });
        });

    },
    flagCourses: function() {
        $('.flag-course').unbind('click').click(function(event) {
            var $this = $(this);
            var flag_type = $(this).data("type");
            var course_id = $(this).parents('tr').data("course");
            var term_id = $(this).parents('tr').data("term");
            var crn = $(this).parents('tr').data("crn");
            var sis_course_id = $(this).parents('tr').data("sis");
            var course_name = $(this).parents('tr').find('.course_name').text();
            var section_code = $(this).parents('tr').find('.section_code').text();
            var total_students = $(this).parents('tr').find('.total_students').text();
            var delivery_method = $(this).parents('tr').find('.delivery_method').text();
            var dept_name = $(this).parents('tr').find('.dept_name').text();
            var college_name = $(this).parents('tr').find('.dept_name').data("college_name");
            var college_id = $(this).parents('tr').find('.dept_name').data("college_id");
            var dept_id = $(this).parents('tr').find('.dept_name').data("dept_id");
            var campus_name = $(this).parents('tr').find('.campus_name').text();
            // console.log(course_id)
            // var crn = sis_course_id.replace('202220','').trim();
            // console.log(crn)
            var status = null;
            var flag_class = null;
            if (flag_type === "green") {
                status = 0;
                flag_class = "text-success";
                status_flag = '<div  class="bg-success" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Green</div>';

            }
            if (flag_type === "yellow") {
                status = 1;
                flag_class = "text-warning";
                status_flag = '<div class="bg-warning" style="font-size: 18px;font-weight: 700; text-align: center; background-color:#ff9800;">Orange</div>';


            }
            if (flag_type === "red") {
                status = 2;
                flag_class = "text-danger";
                status_flag = '<div class="bg-danger" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Red</div>';


            }
            $.confirm({
                icon: 'fas fa-exclamation-triangle',
                title: 'Confirmation',
                content: `Do you want to flag this course (s) as: <span class="${flag_class}"> ${flag_type}</span>?`,
                type: 'orange',
                animation: 'zoom',
                closeAnimation: 'scale',
                buttons: {
                    confirm: function() {
                        $.post("action.php", {
                            task: "flagThisCourse",
                            status: status,
                            course_id: course_id,
                            term_id: term_id,
                            course_name: course_name,
                            crn: crn,
                            section_code: section_code,
                            total_students: total_students,
                            delivery_method: delivery_method,
                            dept_name: dept_name,
                            college_name: college_name,
                            college_id: college_id,
                            dept_id: dept_id,
                            campus_name: campus_name,

                        }).done(function(data_str) {
                            $this.parents('tr').find('.status').html(status_flag).attr('data-status', status);

                        });
                    },
                    cancel: function() {
                        // $.alert('Canceled!');
                    }
                }
            });

        });
    },

    retrieveSeatChart: function() {
        $('.students-seat').unbind('click').click(function(event) {
            var course_id = $(this).parents('tr').data("course");
            var crn = $(this).parents('tr').data("crn");
            var course_name = $(this).parents('tr').find('.course_name').text();
            var table = $('#seating-list-table').DataTable();

            table.destroy();

            $("#seating-list-table tbody").html('');
            $('#seating-modal').modal('show');
            $('#seating-modal .modal-title').html(course_name + " Seat Info");
            $(".seat-data-loading").html('<div class="alert alert-success">Loading Course Roster <i class="fa fa-spinner fa-spin " style="font-size:36px;"></i></div>');

            // FlagCourse.retrieveSeatDate(course_id); 

            $.post("action.php", {
                task: "studentlList",
                course_id: course_id,
            }).done(function(data_str) {
                var data = JSON.parse(data_str);

                $("#seating-list-table tbody").html('');

                $.each(data, function(index, value) {

                    var studentName = (value.user.short_name).split(" ");
                    var firstName = studentName[0];
                    var lastName = studentName[1];

                    $("#seating-list-table tbody").append(`
                        <tr data-login="${value.user.login_id}">
                            <td class="d-none">${firstName}</td>
                            <td class="d-none">${lastName}</td>
                            <td class="student_name">${value.user.short_name}</td>
                            <td class="login">${value.user.login_id}</td>
                            <td class="d-none">${value.user.login_id}</td>
                            <td class="d-none">${crn}</td>
                            <td class="main-class-seat"></td>
                            <td class="recitation-class-seat"></td>
                            <td class="other-class-seat"></td>
                            <td class="student_email"></td>
                            <td class="student_phone d-none"></td>
                            <td class="student_phone"></td>
                            <td><button type="button" class="seat-surrounding btn btn-sm btn-secondary">Surrounding</button></td>
                        </tr>
                    `);
                });

                var total_tr = $("#seating-list-table tbody tr").length;
                var total_count = 0;

                $("#seating-list-table tbody tr").each(function() {

                    var tr = $(this);
                    var login_id = $(this).data('login');
                    var course_section_id = $(this).data('section');

                    //retrieve and append student  contact and email to the class Roster

                    $.post("action.php", {
                        task: "retrieveContact",
                        username: login_id
                    }).done(function(data_str) {
                        var data = JSON.parse(data_str);

                        tr.find('.student_email').html(`${login_id.toLowerCase()}@usu.edu`);


                        if (data.length > 0) {

                            if ((data[0].number).length < 7) {

                                var phone_number = `${data[0].areaCode}-${data[0].number}-${data[0].extension}`;

                            } else {

                                var a = data[0].number;
                                var b = "-";
                                var position = 3;
                                var number = [a.slice(0, position), b, a.slice(position)].join('');
                                var phone_number = `${data[0].areaCode}-${number}`;
                            }

                            tr.find('.student_phone').html(phone_number);

                        } else {

                            $.post("action.php", {
                                task: "retrieveHomeContact",
                                username: login_id
                            }).done(function(data_str) {
                                var home_data = JSON.parse(data_str);
                                if (home_data.length > 0) {
                                    if ((home_data[0].number).length < 7) {
                                        var phone_number = `${home_data[0].areaCode}-${home_data[0].number}-${home_data[0].extension}`;
                                    } else {

                                        var a = home_data[0].number;
                                        var b = "-";
                                        var position = 3;
                                        var number = [a.slice(0, position), b, a.slice(position)].join('');
                                        // console.log(number);
                                        var phone_number = `${home_data[0].areaCode}-${number}`;
                                    }


                                    tr.find('.student_phone').html(phone_number);

                                } else {

                                    tr.find('.student_email').html("");
                                    // tr.remove();
                                }
                            });

                        }
                    });

                    $.post("action.php", {
                        task: "retrievseStudentSeat",
                        username: login_id,
                        crn: crn,
                    }).done(function(login_data_str) {

                        var login_data = JSON.parse(login_data_str);
                        var seat_history = $('<div></div>');
                        var main_class_div = $('<ul></ul>');
                        var recitation_div = $('<ul></ul>');
                        var other_div = $('<ul></ul>');

                        total_count++;

                        if (login_data.length > 0) {
                            tr.find('.main-class-seat').append(`${login_data[0].rowLetter}${login_data[0].seatNumber}`);

                            var c_count = 0;
                            var r_count = 0;
                            var o_count = 0;

                            $.each(login_data, function(index, val) {
                                let activityDate = moment(val.activityDate).format('MM-DD-YY');
                                if ((val.courseType).toUpperCase() === "C") {
                                    c_count++;
                                    $(main_class_div).append('<li>' + val.rowLetter + '' + val.seatNumber + ' (' + activityDate + ')</li>');
                                    // console.log(val)

                                }
                                if ((val.courseType).toUpperCase() === "R") {
                                    r_count++;
                                    $(recitation_div).append('<li>' + val.rowLetter + '' + val.seatNumber + ' (' + activityDate + ')</li>');
                                    // console.log(val.rowLetter)

                                }
                                if ((val.courseType).toUpperCase() === "O") {
                                    o_count++;
                                    $(other_div).append('<li>' + val.rowLetter + '' + val.seatNumber + ' (' + activityDate + ')</li>');
                                    // console.log(val.rowLetter)

                                }

                            });


                            tr.attr('data-row', login_data[0].rowLetter).attr('data-seat', login_data[0].seatNumber);

                            var activityDate = moment(login_data[0].activityDate).format('MM-DD-YYYY LT');

                            tr.find('.main-class-seat').html(`${$(main_class_div).html()}`);
                            tr.find('.recitation-class-seat').html(`${$(recitation_div).html()}`);
                            tr.find('.other-class-seat').html(`${$(other_div).html()}`);
                        }

                        if (total_count == total_tr) {

                            $(".seat-data-loading").html('');
                            var table = $('#seating-list-table').DataTable({
                                pageLength: 100,
                                dom: 'Bfrtip',
                                buttons: [{
                                        title: 'Student Seat Records',
                                        text: 'Download CSV',
                                        filename: 'Seat Records ' + crn,
                                        extend: 'excelHtml5',

                                    },
                                    {
                                        extend: 'csv',
                                        text: 'Signal Vine Export',
                                        filename: 'Seat Records ' + crn,
                                        exportOptions: {
                                            columns: [4, 0, 1, 5, 10]
                                        }
                                    }

                                ],
                                lengthMenu: [
                                    [50, 25, 50, -1],
                                    [50, 25, 50, "All"]
                                ],
                            });
                        }

                    });
                });

                FlagCourse.surroundingSeat(crn);

            });

        });

    },
    surroundingSeat: function(crn) {
        $('.seat-surrounding').unbind('click').click(function(event) {


            $("#surrounding-list-table tbody").html('');
            $('.data-loading').html('<i class="fa fa-spinner fa-spin" style="font-size:36px;"></i>');

            var login_id = $(this).parents('tr').find('.login').text();
            var student_name = $(this).parents('tr').find('.student_name').text();



            $('#surrounding-seat-modal').modal('show');
            $('#surrounding-seat-modal .modal-title').html(`${student_name} (${login_id}) Surrounding Seats`);

            FlagCourse.retrieveStudentSeatType(login_id, crn);
            $('#student-main-seat, #student-recitation-seat, #student-other-seat').unbind('change').change(function() {
                var row = $('option:selected', this).data('row');
                var seat = $('option:selected', this).data('seat');
                var type = $('option:selected', this).data('type');

                FlagCourse.retrieveSurroundingData(crn, row, seat, login_id, student_name, type)
            });


        });
    },
    retrieveSurroundingData: function(crn, row, seat, login_id, student_name, type) {
        var radius = 2;
        var termCode = 202220;

        var table = $('#surrounding-list-table').DataTable();
        table.destroy();

        $("#surrounding-list-table tbody").html('');

        if (row && seat) {


            $.post("action.php", {
                task: "retrieveStudentSurrroundingSeat",
                crn: crn,
                termCode: termCode,
                rowLetter: row,
                seatNumber: seat,
                radius: radius,
            }).done(function(seat_data_str) {
                var seat_data = JSON.parse(seat_data_str);
                if (seat_data.status == 404) {

                    $('.data-loading').html(`<div class="alert alert-success">No surrounding seat found!</div>`);

                } else {
                    var completed = 0;

                    $.each(seat_data, function(index, val) {

                        var username = val.username;
                        var studentName = (val.studentName).split(" ");
                        var firstName = studentName[0];
                        var lastName = studentName[1];

                        if ((val.courseType).trim() === type.trim()) {

                            $.post("action.php", {
                                task: "retrieveContact",
                                username: username
                            }).done(function(data_str) {
                                completed++
                                var data = JSON.parse(data_str);
                                // console.log(data)
                                if (data.length > 0) {

                                    if ((data[0].number).length < 7) {

                                        var phone_number = `${data[0].areaCode}-${data[0].number}-${data[0].extension}`;

                                    } else {

                                        var a = data[0].number;
                                        var b = "-";
                                        var position = 3;
                                        var number = [a.slice(0, position), b, a.slice(position)].join('');
                                        var phone_number = `${data[0].areaCode}-${number}`;
                                    }


                                    $("#surrounding-list-table tbody").append(`
                                         <tr data-login="${username}">
                                            <td class="d-none">${firstName}</td>
                                            <td class="d-none">${lastName}</td>
                                            <td>${val.studentName}</td>
                                            <td>${username}</td>
                                            <td class="d-none">${username}</td>
                                            <td class="d-none">${crn}</td>
                                            <td>${val.rowLetter}${val.seatNumber}</td>
                                            <td class="d-none">${phone_number}</td>
                                            <td>${phone_number}</td>
                                            <td><a href="mailto:${username.toLowerCase()}@usu.edu">${username.toLowerCase()}@usu.edu</a></td>
                                            <td>${val.activityDate}</td>
                                        </tr>
                                    `);
                                } else {

                                    $.post("action.php", {
                                        task: "retrieveHomeContact",
                                        username: login_id
                                    }).done(function(data_str) {
                                        var home_data = JSON.parse(data_str);
                                        if (home_data.length > 0) {
                                            if ((home_data[0].number).length < 7) {
                                                var phone_number = `${home_data[0].areaCode}-${home_data[0].number}-${home_data[0].extension}`;
                                            } else {

                                                var a = home_data[0].number;
                                                var b = "-";
                                                var position = 3;
                                                var number = [a.slice(0, position), b, a.slice(position)].join('');
                                                // console.log(number);
                                                var phone_number = `${home_data[0].areaCode}-${number}`;
                                            }


                                            tr.find('.student_phone').html(phone_number);

                                            $("#surrounding-list-table tbody").append(`
                                                <tr data-login="${username}">
                                                    <td class="d-none">${firstName}</td>
                                                    <td class="d-none">${lastName}</td>
                                                    <td>${val.studentName}</td>
                                                    <td>${username}</td>
                                                    <td class="d-none">${username}</td>
                                                    <td class="d-none">${crn}</td>
                                                    <td>${val.rowLetter}${val.seatNumber}</td>
                                                    <td class="d-none">${phone_number}</td>
                                                    <td>${phone_number}</td>
                                                    <td><a href="mailto:${username.toLowerCase()}@usu.edu">${username.toLowerCase()}@usu.edu</a></td>
                                                    <td>${val.activityDate}</td>
                                                </tr>
                                            `);
                                        } else {
                                             $("#surrounding-list-table tbody").append(`
                                                <tr data-login="${username}">
                                                    <td class="d-none">${firstName}</td>
                                                    <td class="d-none">${lastName}</td>
                                                    <td>${val.studentName}</td>
                                                    <td>${username}</td>
                                                    <td class="d-none">${username}</td>
                                                    <td class="d-none">${crn}</td>
                                                    <td>${val.rowLetter}${val.seatNumber}</td>
                                                    <td class="d-none"></td>
                                                    <td></td>
                                                    <td><a href="mailto:${username.toLowerCase()}@usu.edu">${username.toLowerCase()}@usu.edu</a></td>
                                                    <td>${val.activityDate}</td>
                                                </tr>
                                            `);

                                            // tr.find('.student_email').html(`Not Available`);
                                            // tr.remove();
                                        }
                                    });

                                }

                                $('.data-loading').html(``);

                                if (seat_data.length == completed) {

                                    var table = $('#surrounding-list-table').DataTable({
                                        pageLength: 100,
                                        dom: 'Bfrtip',
                                        buttons: [{
                                                title: `${student_name} (${login_id}) Surrounding Seats`,
                                                text: 'Download CSV',
                                                extend: 'excelHtml5',

                                            },
                                            {
                                                extend: 'csv',
                                                text: 'Signal Vine Export',
                                                exportOptions: {
                                                    columns: [4, 0, 1, 5, 7]
                                                }
                                            }

                                        ],
                                        lengthMenu: [
                                            [50, 25, 50, -1],
                                            [50, 25, 50, "All"]
                                        ],
                                    });
                                }
                            });
                        }
                    });
                }
            });

        } else {

            $.alert({
                title: 'error',
                content: 'The student selected has no seat recorded!',
                type: 'orange',
                animation: 'zoom',
            });
        }
    },

    retrieveStudentSeatType: function(username, crn) {
        $('#student-main-seat').html('<option>Select Seat</option>');
        $('#student-recitation-seat').html('<option>Select Seat</option>');
        $('#student-other-seat').html('<option>Select Seat</option>');
        $.post("action.php", {
            task: "retrieveStudentSeatType",
            username: username,
            courseType: "C",
            crn: crn,
        }).done(function(data_str) {

            var seat_data = JSON.parse(data_str);


            $.each(seat_data, function(index, val) {
                let activityDate = moment(val.activityDate).format('MM-DD-YYYY LT');
                $('#student-main-seat').append(`<option data-type="C" data-row="${val.rowLetter}" data-seat="${val.seatNumber}">${val.rowLetter}${val.seatNumber} - ${activityDate}</option>`);
            });

        });
        $.post("action.php", {
            task: "retrieveStudentSeatType",
            username: username,
            courseType: "R",
            crn:crn
        }).done(function(data_str) {

            var seat_data = JSON.parse(data_str);


            $.each(seat_data, function(index, val) {
                let activityDate = moment(val.activityDate).format('MM-DD-YYYY LT');
                $('#student-recitation-seat').append(`<option  data-type="R" data-row="${val.rowLetter}" data-seat="${val.seatNumber}">${val.rowLetter}${val.seatNumber} - ${activityDate}</option>`);
            });

        });
        $.post("action.php", {
            task: "retrieveStudentSeatType",
            username: username,
            courseType: "O",
            crn:crn
        }).done(function(data_str) {

            var seat_data = JSON.parse(data_str);

            $.each(seat_data, function(index, val) {
                let activityDate = moment(val.activityDate).format('MM-DD-YYYY LT');
                $('#student-other-seat').append(`<option data-type="O" data-row="${val.rowLetter}" data-seat="${val.seatNumber}">${val.rowLetter}${val.seatNumber} - ${activityDate}</option>`);
            });


        });
    },
    retrieveFlagedCourses: function() {
        $.post("action.php", {
            task: "retrieveFlagedCourses",


        }).done(function(data_str) {
            var data = JSON.parse(data_str);
            // console.log(data)
            $.each(data, function(index, value) {
                var section_code = "No Section";
                if (value.status == 0) {
                    status = '<div  class="bg-success" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Green</div>';

                }
                if (value.status == 1) {

                    status = '<div  style="font-size: 18px;font-weight: 700; text-align: center; background-color:#ff9800;">Orange</div>';
                }
                if (value.status == 2) {

                    status = '<div class="bg-danger" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Red</div>';
                }

                if (value.section_code !== undefined) {
                    section_code = value.section_code;

                }

                $("#flaged-course-list-table tbody").append(`
                        <tr data-id="${value.course_id}" data-termId=${value.term_id}>
                            <td class="course_name"><a href="https://usu.instructure.com/courses/${value.course_id}" target="_blank">${value.course_name}</a></td>
                            <td class="section_code">${section_code}</td>
                            <td>${status}</td>
                            <td>${value.delivery_method}</td>
                            <td>${value.dept_name}</td>
                            <td>${value.campus_name}</td>
                             <td>
                                <div>
                                    <button type="button" class="btn btn-sm  btn-success  mr-2 flag-course" data-type="green">Green</button>
                                    <button type="button" class="btn btn-sm  btn-warning mr-2 flag-course" style="background-color:#ff9800;"  data-type="yellow">Orange</button>
                                    <button type="button" class="btn btn-sm btn-danger  mr-2 flag-course" data-type="red">Red</button>
                                </div>
                            </td>
                            <td>
                                <div>
                                    <button type="button" class="teacher-info btn btn-sm btn-outline-secondary">Info</button>
                                    <button type="button" class="students-seat btn btn-sm btn-outline-secondary">Seat</button>
                                </div>
                            </td>
                         
                        </tr>
                    `);
            });
            var table = $('#flaged-course-list-table').DataTable();
        });
    },



};

$(document).ready(function() {
    "use strict";
    // $('table').DataTable();
    FlagCourse.init();
});