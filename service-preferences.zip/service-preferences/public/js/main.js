var CovidCourseTracker = {
    courseId: null,
    data: null,

    init: function() {

        this.retrieveFlagedCourses();
        // this.retrieveAllUserData();

    },

    //   retrieveAllUserData: function() {

    //      // $.getJSON("js/correct_crn.json", function(result){
    //      //    var newDict = {}

    //      //    for(var i=0; i<result.length; i++) {
    //      //        newDict[result[i]['courseid']] = result[i]['coursename'];
    //      //    }
    //      //    console.log(newDict)
    //      //    });

    //     // $.post("action.php", {
    //     //     task: "retrieveAllUserData",

    //     // }).done(function(data_str) {
    //         // var data = JSON.parse(data_str);
    //         var course_list_array = [391132,659126,672819,658987,657432,675365,659852,681609,664045,659762,659507,658795,661521,679572,678178,662045,659357,671487,659858,659042,665347,664611,660092,671736,658551,658620,681589,657526,660529,659274,657581,661988,660105,658899,678176,661569,659230,664581,659764,659075,681184,659782,657816,678258,659152,681494,657521,679587,660922,658488,658722,675437,657507,657542,675658,657930,663112,681580,658437,661984,659108,658163,659337,672057,659333,660539,681565,658443,657942,659531,657638,680634,658232,657650,657516,658962,659106,681353,657387,665836,676937,679734,681194,658765,658516,681498,675779,681590,659130,677292,658298,675340,659783,675766,675502,657806,660623,663789,661361,660916,681542,659466,659047,660229,666778,661884,659362,663688,657523,660975,657434,657672,677293,658573,659628,672833,659519,658829,676938,675651,659900,675759,657589,666014,681629,675642,659637,658963,659820,663262,672808,680706,657584,658844,657885,660615,657501,658508,657313,657653,659319,657478,679284,659305,660571,661067,681499,101,658598,658980,659125,658558,666724,657532,678183,659766,681235,681547,657899,675488,658843,657193,658374,661170,657534,658609,658513,658816,658368,658799,660464,657985,681493,657796,658784,657253,659576,666051,657691,659671,657790,659844,676898,658894,660928,678749,678751,664741,659379,659329,679658,681618,657504,657428,665135,657676,660233,659367,681185,658281,660619,660235,675648,658376,676856,658015,658738,658993,681050,659415,664584,659768,665989,663787,662426,671821,658981,659033,657674,680451,658562,658602,678750,678560,681625,657594,660148,658073,659524,657333,659144,657443,663097,681719,658826,681606,660339,659364,681495,659201,657728,681486,661356,658809,662057,658166,659785,659190,675319,681231,662749,657563,664976,657435,658995,659584,661582,678954,657887,659036,676741,681611,664751,658234,658491,664988,659272,657528,658863,659097,662431,658730,658176,675357,657567,675654,661776,659721,658240,659299,659141,658512,657812,681440,658218,664917,675331,681409,675353,659789,659814,659083,657937,659332,658885,659685,660161,661423,659277,659193,658997,657997,680543,675486,681567,679736,677587,659788,659283,677102,664979,659377,659773,672852,658380,659817,661533,659315,659856,675311,658561,658189,660986,681500,659086,657438,659100,675296,658035,660343,672125,680300,657850,677290,657647,658850,675355,661572,658917,658222,658665,661483,663579,658906,657238,661584,659633,659729,658195,657661,677302,681608,678827,661839,664743,678335,675646,681442,676928,675489,658294,658149,664906,658000,658155,657509,678181,664932,666894,657388,659071,659614,659550,657582,657381,681588,664923,658785,659540,663121,675875,658951,658506,671702,658776,675762,659588,675315,659603,659004,662883,659135,666777,658356,657231,663785,661580,658718,659105,657208,678179,657513,675543,660408,657249,657290,660518,661585,663826,661097,675367,657753,681314,661478,658576,681575,657771,681597,658960,657741,660447,661853,657892,660389,672240,660641,657656,665945,659041,657663,665130,661888,659848,658958,658048,659529,675782,675395,666714,658689,666709,659079,664489,659619,664681,675656,658713,661899,657429,678255,671547,660515,660707,658288,659239,657670,657952,678256,661895,657239,658377,658907,658666,658375,659470,657549,678184,659279,657751,680576,681540,673473,660971,658605,659535,657257,659541,657577,661523,658769,658521,659517,660561,659811,658667,659311,658462,659342,662738,657740,661891,658798,657648];
    //         var course_array = [];
    //         var total = 0;
    //         for (var i = 0; i < course_list_array.length; i++) {
    //            // console.log(course_list_array[i]); 
    //              $.post("action.php", {

    //                 task: "retrievecourseSis",
    //                 course_id: course_list_array[i],

    //             }).done(function(data_str) {
    //                 total++;
    //                 var c_data = JSON.parse(data_str);
    //                 var sis_course_id = c_data.sis_course_id;
    //                 if ((sis_course_id).indexOf(".") !== -1) {
    //                     var crn_array = sis_course_id.split('.');
    //                     var newcrn = crn_array[0];
    //                 } else {
    //                     var newcrn = (sis_course_id).substring(0, sis_course_id.length - 6);
    //                 }
    //                 // console.log(c_data)
    //                 course_array.push({
    //                     "coursename":c_data.name,
    //                     "courseid":c_data.id,
    //                     "newcrn" :newcrn
    //                 });
    //                 if (course_list_array.length==total) {

    //                     console.log( course_array )
    //                 }

    //             });
    //         }
    //         // $.each(data, function(index, value) {
    //             // total++;
    //             // $.post("action.php", {

    //             //     task: "retrievecourseSis",
    //             //     course_id: value.courseId,

    //             // }).done(function(data_str) {
    //             //     var c_data = JSON.parse(data_str);
    //             //     var sis_course_id = c_data.sis_course_id;
    //             //     if ((sis_course_id).indexOf(".") !== -1) {
    //             //         var crn_array = sis_course_id.split('.');
    //             //         var newcrn = crn_array[0];
    //             //     } else {
    //             //         var newcrn = (sis_course_id).substring(0, sis_course_id.length - 6);
    //             //     }
    //             //     // console.log(newcrn)
    //             //     course_array.push({
    //             //         "coursename":value.courseName,
    //             //         "courseid":value.courseId,
    //             //         "oldcrn" :value.crn,
    //             //         "newcrn" :newcrn
    //             //     });
    //             //     if (data.length==total) {

    //             //         console.log( course_array )
    //             //     }

    //             // });
    //             // console.log(value.courseId)
    //             // console.log(value.crn)
    //             // console.log(value.newcrn)
    //         // });
    //     // });

    // },
    sendNotification: function(course_id, teachers) {
        $('.send_notification').unbind('click').click(function(event) {

            $.confirm({
                icon: 'fas fa-exclamation-triangle',
                title: 'Confirmation',
                content: `Do you want to send Notification to the class and an email to the intructor(s)?`,
                type: 'orange',
                animation: 'zoom',
                closeAnimation: 'scale',
                draggable: true,
                dragWindowBorder: false,
                buttons: {
                    confirm: function() {

                        $.post("action.php", {

                            task: "retrieveThisCourseFlag",
                            course_id: course_id,

                        }).done(function(data_str) {

                            // console.log(data_str)
                            var data = JSON.parse(data_str);
                            var status = data.status;
                            var course_name = data.course_name;
                            var course_id = data.course_id;
                            var message = "";
                            var title = `Covid Classroom Status`;


                            // console.log(course_id)
                            if (status == 0) {
                                message = `The Covid Classroom Status for ${course_name} has has been updated to Green. 
                                You can learn more about the Green classroom status and action required on your part at usu.edu/covid-19/students/classroom-exposure/
                            `;

                            }

                            if (status == 1) {

                                message = `The Covid Classroom Status for ${course_name}  has been updated to Orange. 
                             You can learn more about the Orange classroom status and action required on your part at usu.edu/covid-19/students/classroom-exposure/ 
                            `;
                            }

                            if (status == 2) {

                                message = `The Covid Classroom Status for ${course_name} has been updated to RED/Remote Delivery.  
                                All students will attend this class via Zoom until USU Case Containment has completed the classroom exposure investigation.  
                                During the investigative process, Case Containment Investigators will continue to contact those exposed. 
                                You can learn more about the RED classroom status and action required on your part at  
                                https://www.usu.edu/covid-19/students/classroom-exposure/. 
                                Your instructor will provide the Zoom link and further course-related instructions through Canvas or an email.
                                If you are vaccinated, CDC guidance indicates; People who are fully vaccinated do NOT need to quarantine after contact with someone who
                                had COVID-19 unless they have symptoms.
                                However, fully vaccinated people should get tested 5-7 days after their exposure, even if they do not have symptoms and wear
                                a mask indoors in public for 14 days following exposure or until their test result is negative.`;
                                // console.log(teachers)

                                $.each(teachers, function(index, value) {
                                    var user_id = value.id;
                                    $.post("action.php", {

                                        task: "userDetail",
                                        user_id: user_id,

                                    }).done(function(user_data) {

                                        var user = JSON.parse(user_data);
                                        $.post("action.php", {

                                            task: "sendEmail",
                                            intructor_email: user.primary_email,
                                            instructor_name: user.name,
                                            course_name: course_name,


                                        });
                                    });

                                });

                            }


                            $.post("action.php", {
                                task: "NewAnnouncement",
                                course_id: course_id,
                                title: title,
                                message: message,

                            }).done(function(data_str) {

                                $('#info-modal').modal('hide');
                                $.alert({
                                    title: 'Success!',
                                    content: 'The notification has been sent!',
                                    type: 'green',
                                    draggable: true,
                                    dragWindowBorder: false,
                                });
                            });
                        });

                    },
                    cancel: function() {
                        // $.alert('Canceled!');
                    }
                }
            });
        });

    },

    retrieveTeachers: function() {
        $('.teacher-info').unbind('click').click(function(event) {
            var course_id = $(this).parents('tr').data("course");
            var crn = $(this).parents('tr').data("crn");
            var course_name = $(this).parents('tr').find('.course_name').text();
            var course_status = $(this).parents('tr').find('.status').data("status");
            var students = $(this).parents('tr').data("std");

            $('.publish-status').html('<i class="fa fa-spinner" style="font-size:36px; fa-spin"></i>');
            $('#teacher-info').html('');
            $("#status-history-table tbody").html('');
            $('#info-modal').modal('show');
            $('#info-modal .modal-title').html(course_name + " Info");
            $('.total-student').html(students);
            // console.log(course_status)

            // $.post("action.php", {
            //     task: "retrieveTeachers",
            //     course_id: course_id,
            // }).done(function(data_str) {
            //     var data = JSON.parse(data_str);
            //     $.each(data, function(index, value) {

            //         $('#teacher-info').append(`<li><a href="${value.html_url}" target="_blank">${value.user.name} <i class="fas fa-external-link-alt"></i><a/></li `);
            //         // console.log(value)
            //     });
            // });

            $.post("action.php", {
                task: "retrieveCourseDetail",
                course_id: course_id,
            }).done(function(data_str) {
                var data = JSON.parse(data_str);
                var teachers = data.teachers;
                // console.log(teachers)
                CovidCourseTracker.sendNotification(course_id, teachers);

                $.each(teachers, function(index, value) {
                    // $('#teacher-info').append(`<li><a href="${value.html_url}" target="_blank">${value.display_name} <i class="fas fa-external-link-alt"></i><a/></li `);
                    $('#teacher-info').append(`<li><a href="https://usu.instructure.com/courses/${course_id}/users/${teachers[0].id}" target="_blank">${value.display_name} <i class="fas fa-external-link-alt"></i><a/></li `);
                });
                // console.log(data)
                if (data.workflow_state === "available") {
                    $('.publish-status').html('This course is Available (Published)');
                }
                if (data.workflow_state === "unpublished") {
                    $('.publish-status').html('This course is Unpublished');
                    $('.send_notification').attr("disabled", "disabled");
                }
                if (data.workflow_state === "deleted") {
                    $('.publish-status').html('This course has been deleted');
                    $('.send_notification').attr("disabled", "disabled");
                }
                if (data.workflow_state === "completed") {
                    $('.publish-status').html('This course has been completed');
                    $('.send_notification').attr("disabled", "disabled");
                }
            });

            $.post("action.php", {
                task: "retrieveStatusHistory",
                course_id: course_id,
            }).done(function(data_str) {
                var data = JSON.parse(data_str);
                // console.log(data)
                $.each(data, function(index, value) {
                    if (value.status == 0) {
                        status = '<div  class="bg-success" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Green</div>';

                    }
                    if (value.status == 1) {

                        status = '<div class="bg-warning" style="font-size: 18px;font-weight: 700; text-align: center; background-color:#ff9800;">Orange</div>';
                    }
                    if (value.status == 2) {

                        status = '<div class="bg-danger" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Red</div>';
                    }
                    $("#status-history-table tbody").append(`
                        <tr>
                            <td class="course_name">${value.flaged_at}</td>
                            <td >${status}</td>
                          
                        </tr>
                    `);
                });
            });
        });


    },

    retrieveSeatChart: function() {
        $('.students-seat').unbind('click').click(function(event) {
            var course_id = $(this).parents('tr').data("course");
            var crn = $(this).parents('tr').data("crn");
            var course_name = $(this).parents('tr').find('.course_name').text();
            var table = $('#seating-list-table').DataTable();

            table.destroy();

            $("#seating-list-table tbody").html('');
            $('#seating-modal').modal('show');
            $('#seating-modal .modal-title').html(course_name + " Seat Info");
            $(".seat-data-loading").html('<div class="alert alert-success">Loading Course Roster <i class="fa fa-spinner fa-spin " style="font-size:36px;"></i></div>');

            // CovidCourseTracker.retrieveSeatDate(course_id); 

            $.post("action.php", {
                task: "studentlList",
                course_id: course_id,
            }).done(function(data_str) {
                var data = JSON.parse(data_str);
                
                $("#seating-list-table tbody").html('');

                $.each(data, function(index, value) {

                    var studentName = (value.user.short_name).split(" ");
                    var firstName = studentName[0];
                    var lastName = studentName[1];

                    $("#seating-list-table tbody").append(`
                        <tr data-login="${value.user.login_id}">
                            <td class="d-none">${firstName}</td>
                            <td class="d-none">${lastName}</td>
                            <td class="student_name">${value.user.short_name}</td>
                            <td class="login">${value.user.login_id}</td>
                            <td class="d-none">${value.user.login_id}</td>
                            <td class="d-none">${crn}</td>
                            <td class="main-class-seat"></td>
                            <td class="recitation-class-seat"></td>
                            <td class="other-class-seat"></td>
                            <td class="student_email"></td>
                            <td class="student_phone d-none"></td>
                            <td class="student_phone"></td>
                            <td><button type="button" class="seat-surrounding btn btn-sm btn-secondary">Surrounding</button></td>
                        </tr>
                    `);
                });

                var total_tr = $("#seating-list-table tbody tr").length;
                var total_count = 0;

                $("#seating-list-table tbody tr").each(function() {

                    var tr = $(this);
                    var login_id = $(this).data('login');
                    var course_section_id = $(this).data('section');

                    //retrieve and append student  contact and email to the class Roster

                    $.post("action.php", {
                        task: "retrieveContact",
                        username: login_id
                    }).done(function(data_str) {
                        var data = JSON.parse(data_str);

                        tr.find('.student_email').html(`${login_id.toLowerCase()}@usu.edu`);



                        if (data.length > 0) {
                            if ((data[0].number).length < 7) {

                                var phone_number = `${data[0].areaCode}-${data[0].number}-${data[0].extension}`;
                            } else {

                                var a = data[0].number;
                                var b = "-";
                                var position = 3;
                                var number = [a.slice(0, position), b, a.slice(position)].join('');
                                // console.log(number);
                                var phone_number = `${data[0].areaCode}-${number}`;
                            }
                            tr.find('.student_phone').html(phone_number);

                        } else {

                            $.post("action.php", {
                                task: "retrieveHomeContact",
                                username: login_id
                            }).done(function(data_str) {
                                var home_data = JSON.parse(data_str);
                                if (home_data.length > 0) {
                                    if ((home_data[0].number).length < 7) {
                                        var phone_number = `${home_data[0].areaCode}-${home_data[0].number}-${home_data[0].extension}`;
                                    } else {

                                        var a = home_data[0].number;
                                        var b = "-";
                                        var position = 3;
                                        var number = [a.slice(0, position), b, a.slice(position)].join('');
                                        // console.log(number);
                                        var phone_number = `${home_data[0].areaCode}-${number}`;
                                    }

                                    tr.find('.student_phone').html(phone_number);

                                } else {

                                    tr.find('.student_email').html("");
                                    // tr.remove();
                                }
                            });

                        }
                    });

                    $.post("action.php", {
                        task: "retrievseStudentSeat",
                        username: login_id,
                    }).done(function(login_data_str) {

                        var login_data = JSON.parse(login_data_str);
                        var seat_history = $('<div></div>');
                        var main_class_div = $('<ul></ul>');
                        var recitation_div = $('<ul></ul>');
                        var other_div = $('<ul></ul>');

                        total_count++;

                        if (login_data.length > 0) {
                            tr.find('.main-class-seat').append(`${login_data[0].rowLetter}${login_data[0].seatNumber}`);

                            var c_count = 0;
                            var r_count = 0;
                            var o_count = 0;

                            $.each(login_data, function(index, val) {
                                let activityDate = moment(val.activityDate).format('MM-DD-YY');
                                if ((val.courseType).toUpperCase() === "C") {
                                    c_count++;
                                    $(main_class_div).append('<li>' + val.rowLetter + '' + val.seatNumber + ' (' + activityDate + ')</li>');
                                    // console.log(val)

                                }
                                if ((val.courseType).toUpperCase() === "R") {
                                    r_count++;
                                    $(recitation_div).append('<li>' + val.rowLetter + '' + val.seatNumber + ' (' + activityDate + ')</li>');
                                    // console.log(val.rowLetter)

                                }
                                if ((val.courseType).toUpperCase() === "O") {
                                    o_count++;
                                    $(other_div).append('<li>' + val.rowLetter + '' + val.seatNumber + ' (' + activityDate + ')</li>');
                                    // console.log(val.rowLetter)

                                }

                            });


                            tr.attr('data-row', login_data[0].rowLetter).attr('data-seat', login_data[0].seatNumber);

                            var activityDate = moment(login_data[0].activityDate).format('MM-DD-YYYY LT');

                            tr.find('.main-class-seat').html(`${$(main_class_div).html()}`);
                            tr.find('.recitation-class-seat').html(`${$(recitation_div).html()}`);
                            tr.find('.other-class-seat').html(`${$(other_div).html()}`);
                        }

                        if (total_count == total_tr) {

                            $(".seat-data-loading").html('');
                            var table = $('#seating-list-table').DataTable({
                                pageLength: 100,
                                dom: 'Bfrtip',
                                buttons: [{
                                        title: 'Student Seat Records',
                                        text: 'Download CSV',
                                        filename: 'Seat Records ' + crn,
                                        extend: 'excelHtml5',

                                    },
                                    {
                                        extend: 'csv',
                                        text: 'Signal Vine Export',
                                        filename: 'Seat Records ' + crn,
                                        exportOptions: {
                                            columns: [4, 0, 1, 5, 10]
                                        }
                                    }


                                ],

                                lengthMenu: [
                                    [50, 25, 50, -1],
                                    [50, 25, 50, "All"]
                                ],
                            });
                        }

                    });
                });

                CovidCourseTracker.surroundingSeat(crn);

            });

        });

    },
    retrieveStudentSeatType: function(username, crn) {
        $('#student-main-seat').html('<option>Select Seat</option>');
        $('#student-recitation-seat').html('<option>Select Seat</option>');
        $('#student-other-seat').html('<option>Select Seat</option>');
        $.post("action.php", {
            task: "retrieveStudentSeatType",
            username: username,
            courseType: "C",
            crn: crn,
        }).done(function(data_str) {
            console.log(crn)
            var seat_data = JSON.parse(data_str);

            $.each(seat_data, function(index, val) {
                let activityDate = moment(val.activityDate).format('MM-DD-YYYY LT');
                $('#student-main-seat').append(`<option data-type="C" data-row="${val.rowLetter}" data-seat="${val.seatNumber}">${val.rowLetter}${val.seatNumber} - ${activityDate}</option>`);
            });

        });
        $.post("action.php", {
            task: "retrieveStudentSeatType",
            username: username,
            courseType: "R",
            crn: crn,
        }).done(function(data_str) {

            var seat_data = JSON.parse(data_str);

            $.each(seat_data, function(index, val) {
                let activityDate = moment(val.activityDate).format('MM-DD-YYYY LT');
                $('#student-recitation-seat').append(`<option  data-type="R" data-row="${val.rowLetter}" data-seat="${val.seatNumber}">${val.rowLetter}${val.seatNumber} - ${activityDate}</option>`);
            });

        });
        $.post("action.php", {
            task: "retrieveStudentSeatType",
            username: username,
            courseType: "O",
            crn: crn,
        }).done(function(data_str) {

            var seat_data = JSON.parse(data_str);

            $.each(seat_data, function(index, val) {
                let activityDate = moment(val.activityDate).format('MM-DD-YYYY LT');
                $('#student-other-seat').append(`<option data-type="O" data-row="${val.rowLetter}" data-seat="${val.seatNumber}">${val.rowLetter}${val.seatNumber} - ${activityDate}</option>`);
            });


        });
    },
    surroundingSeat: function(crn) {
        $('.seat-surrounding').unbind('click').click(function(event) {


            $("#surrounding-list-table tbody").html('');
            $('.data-loading').html('<i class="fa fa-spinner fa-spin" style="font-size:36px;"></i>');

            var login_id = $(this).parents('tr').find('.login').text();
            var student_name = $(this).parents('tr').find('.student_name').text();



            $('#surrounding-seat-modal').modal('show');
            $('#surrounding-seat-modal .modal-title').html(`${student_name} (${login_id}) Surrounding Seats`);

            CovidCourseTracker.retrieveStudentSeatType(login_id, crn);
            $('#student-main-seat, #student-recitation-seat, #student-other-seat').unbind('change').change(function() {
                var row = $('option:selected', this).data('row');
                var seat = $('option:selected', this).data('seat');
                var type = $('option:selected', this).data('type');
                CovidCourseTracker.retrieveSurroundingData(crn, row, seat, login_id, student_name, type)
            });


        });
    },
    retrieveSurroundingData: function(crn, row, seat, login_id, student_name, type) {
        var radius = 2;
        var termCode = 202220;

        var table = $('#surrounding-list-table').DataTable();
        table.destroy();

        $("#surrounding-list-table tbody").html('');

        if (row && seat) {


            $.post("action.php", {
                task: "retrieveStudentSurrroundingSeat",
                crn: crn,
                termCode: termCode,
                rowLetter: row,
                seatNumber: seat,
                radius: radius,
            }).done(function(seat_data_str) {
                var seat_data = JSON.parse(seat_data_str);
                if (seat_data.status == 404) {

                    $('.data-loading').html(`<div class="alert alert-success">No surrounding seat found!</div>`);

                } else {

                    var completed = 0;

                    $.each(seat_data, function(index, val) {

                        var username = val.username;
                        var studentName = (val.studentName).split(" ");
                        var firstName = studentName[0];
                        var lastName = studentName[1];

                        if ((val.courseType).trim() === type.trim()) {

                            $.post("action.php", {
                                task: "retrieveContact",
                                username: username
                            }).done(function(data_str) {
                                completed++
                                var data = JSON.parse(data_str);

                                // console.log(data)
                                // console.log(firstName)
                                if (data.length > 0) {

                                    if ((data[0].number).length < 7) {

                                        var phone_number = `${data[0].areaCode}-${data[0].number}-${data[0].extension}`;

                                    } else {

                                        var a = data[0].number;
                                        var b = "-";
                                        var position = 3;
                                        var number = [a.slice(0, position), b, a.slice(position)].join('');
                                        var phone_number = `${data[0].areaCode}-${number}`;
                                    }


                                    $("#surrounding-list-table tbody").append(`
                                         <tr data-login="${username}">
                                            <td class="d-none">${firstName}</td>
                                            <td class="d-none">${lastName}</td>
                                            <td>${val.studentName}</td>
                                            <td>${username}</td>
                                            <td class="d-none">${username}</td>
                                            <td class="d-none">${crn}</td>
                                            <td>${val.rowLetter}${val.seatNumber}</td>
                                            <td class="d-none">${phone_number}</td>
                                            <td>${phone_number}</td>
                                            <td><a href="mailto:${username.toLowerCase()}@usu.edu">${username.toLowerCase()}@usu.edu</a></td>
                                            <td>${val.activityDate}</td>
                                        </tr>
                                    `);
                                } else {

                                    $.post("action.php", {
                                        task: "retrieveHomeContact",
                                        username: login_id
                                    }).done(function(data_str) {
                                        var home_data = JSON.parse(data_str);
                                        if (home_data.length > 0) {
                                            if ((home_data[0].number).length < 7) {
                                                var phone_number = `${home_data[0].areaCode}-${home_data[0].number}-${home_data[0].extension}`;
                                            } else {

                                                var a = home_data[0].number;
                                                var b = "-";
                                                var position = 3;
                                                var number = [a.slice(0, position), b, a.slice(position)].join('');
                                                // console.log(number);
                                                var phone_number = `${home_data[0].areaCode}-${number}`;
                                            }


                                            tr.find('.student_phone').html(phone_number);

                                            $("#surrounding-list-table tbody").append(`
                                                <tr data-login="${username}">
                                                    <td class="d-none">${firstName}</td>
                                                    <td class="d-none">${lastName}</td>
                                                    <td>${val.studentName}</td>
                                                    <td>${username}</td>
                                                    <td class="d-none">${username}</td>
                                                    <td class="d-none">${crn}</td>
                                                    <td>${val.rowLetter}${val.seatNumber}</td>
                                                    <td class="d-none">${phone_number}</td>
                                                    <td>${phone_number}</td>
                                                    <td><a href="mailto:${username.toLowerCase()}@usu.edu">${username.toLowerCase()}@usu.edu</a></td>
                                                    <td>${val.activityDate}</td>
                                                </tr>
                                            `);
                                        } else {
                                            $("#surrounding-list-table tbody").append(`
                                                <tr data-login="${username}">
                                                    <td class="d-none">${firstName}</td>
                                                    <td class="d-none">${lastName}</td>
                                                    <td>${val.studentName}</td>
                                                    <td>${username}</td>
                                                    <td class="d-none">${username}</td>
                                                    <td class="d-none">${crn}</td>
                                                    <td>${val.rowLetter}${val.seatNumber}</td>
                                                    <td class="d-none"></td>
                                                    <td></td>
                                                    <td><a href="mailto:${username.toLowerCase()}@usu.edu">${username.toLowerCase()}@usu.edu</a></td>
                                                    <td>${val.activityDate}</td>
                                                </tr>
                                            `);
                                            // tr.find('.student_email').html(`Not Available`);
                                            // tr.remove();
                                        }
                                    });

                                }

                                if (seat_data.length == completed) {
                                    $('.data-loading').html(``);

                                    var table = $('#surrounding-list-table').DataTable({
                                        pageLength: 100,
                                        dom: 'Bfrtip',

                                        buttons: [{
                                                title: `${student_name} (${login_id}) Surrounding Seats`,
                                                text: 'Download CSV',
                                                extend: 'excelHtml5',

                                            },
                                            {
                                                extend: 'csv',
                                                text: 'Signal Vine Export',
                                                exportOptions: {
                                                    columns: [4, 0, 1, 5, 7]
                                                }
                                            }



                                        ],

                                        lengthMenu: [
                                            [50, 25, 50, -1],
                                            [50, 25, 50, "All"]
                                        ],
                                    });
                                }
                            });
                        }
                    });
                }
            });

        } else {

            $.alert({
                title: 'error',
                content: 'The student selected has no seat recorded!',
                type: 'orange',
                animation: 'zoom',
            });
        }
    },

    retrieveFlagedCourses: function() {
        var term_id = 202220;
        
        $.post("action.php", {
            task: "retrieveFlagedCourses",
            term_id:term_id

        }).done(function(data_str) {
            var data = JSON.parse(data_str);
            $.each(data, function(index, value) {
                if (value.status == 0) {
                    status = '<div  class="bg-success" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Green</div>';

                }
                if (value.status == 1) {

                    status = '<div  style="font-size: 18px;font-weight: 700; text-align: center; background-color:#ff9800;">Orange</div>';
                }
                if (value.status == 2) {

                    status = '<div class="bg-danger" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Red</div>';
                }


                var section_code = "No Section";
                if (value.section_code !== null) {
                    section_code = value.section_code;
                }
                // console.log(value.term_id)
                // <td class="section_code">${section_code}</td>
                $("#flaged-course-list-table tbody").append(`
                    <tr data-course="${value.course_id}" data-term=${value.term_id} data-std="${value.total_students}" data-crn="${value.crn}">
                        <td class="course_name"><a href="https://usu.instructure.com/courses/${value.course_id}" target="_blank">${value.course_name}</a> <button type="button" class="btn btn-sm btn-light section-list"><i class="fas fa-external-link-alt"></i></button></td>
                        <td class="status" data-status="${value.status}">${status}</td>
                        <td>${value.delivery_method}</td>
                        <td class="dept_name" data-college_name="${value.college_name}" data-college_id="${value.college_id}" data-dept_id="${value.dept_id}">${value.dept_name}</td>
                        <td>${value.campus_name}</td>
                        <td>
                           <div>
                                <button type="button" class="btn btn-sm btn-success mr-2 flag-course" data-type="green">Green</button>
                                <button type="button" class="btn btn-sm btn-danger  mr-2 flag-course" data-type="red">Red</button>
                                <button type="button" class="btn btn-sm btn-warning mr-2 flag-course" style="background-color:#ff9800;" data-type="yellow">Orange</button>
                          
                            </div>
                        </td>
                        <td>
                           <div>
                                <button type="button" class="teacher-info btn btn-sm btn-outline-secondary">Info</button>
                                <button type="button" class="students-seat btn btn-sm btn-outline-secondary">Seat</button>
                            </div>
                        </td>
                    </tr>
                `);
            });
            CovidCourseTracker.flagCourses();
            CovidCourseTracker.retrieveTeachers();
            CovidCourseTracker.retrieveSeatChart();
            CovidCourseTracker.retrieveCourseSection();
            var table = $('#flaged-course-list-table').DataTable({
                pageLength: -1,
                lengthMenu: [
                    [50, 25, 50, -1],
                    [50, 25, 50, "All"]
                ],
            });
        });
    },
    retrieveCourseSection: function() {
        $('.section-list').unbind('click').click(function(event) {
            $('.course-section-list').html('');
            $('#sections-modal').modal('show');
            $(".section-data-loading").html('<div class="alert alert-success">Loading Course Sections <i class="fa fa-spinner fa-spin " style="font-size:36px;"></i></div>');

            var tr = $(this);
            var course_id = $(this).parents('tr').data('course');
            var course_name = $(this).parents('tr').find('.course_name a').text();

            $('.section-modal-title').html(course_name + " Sections");
            // retrieve course section and display

            $.post("action.php", {
                task: "retrieveCourseSections",
                course_id: course_id,
            }).done(function(section_str) {
                var section = JSON.parse(section_str);
                console.log(section);
                if (section.sections.length > 0) {
                    $.each(section.sections, function(index, value) {

                        $('.course-section-list').append(`<li class="list-group-item"><a href="https://usu.instructure.com/courses/${course_id}/sections/${value.id}" target="_blank">${value.name}</a></li>`)
                    });
                    $(".section-data-loading").html('');
                } else {
                    $('.course-section-list').html('This course has no section available.');
                    $(".section-data-loading").html('');
                }
                // tr.find('.section_code').html(section.name);
            });
            // $("#course-list-table tbody tr").each(function() { });
        });
    },

    flagCourses: function() {
        $('.flag-course').unbind('click').click(function(event) {
            var $this = $(this);
            var flag_type = $(this).data("type");
            var course_id = $(this).parents('tr').data("course");
            var term_id = $(this).parents('tr').data("term");
            var course_name = $(this).parents('tr').find('.course_name').text();
            var section_code = $(this).parents('tr').find('.section_code').text();
            var total_students = $(this).parents('tr').find('.total_students').text();
            var delivery_method = $(this).parents('tr').find('.delivery_method').text();
            var dept_name = $(this).parents('tr').find('.dept_name').text();
            var campus_name = $(this).parents('tr').find('.campus_name').text();
            var college_name = $(this).parents('tr').find('.dept_name').data("college_name");
            var college_id = $(this).parents('tr').find('.dept_name').data("college_id");
            var dept_id = $(this).parents('tr').find('.dept_name').data("dept_id");
            console.log(course_id)
            console.log(term_id)
            var status = null;
            var flag_class = null;
            if (flag_type === "green") {
                status = 0;
                flag_class = "text-success";
                status_flag = '<div  class="bg-success" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Green</div>';

            }
            if (flag_type === "yellow") {
                flag_type = "Orange";
                status = 1;
                flag_class = "text-warning";
                status_flag = '<div class="bg-warning" style="font-size: 18px;font-weight: 700; text-align: center; background-color:#ff9800;">Orange</div>';
            }
            if (flag_type === "red") {
                status = 2;
                flag_class = "text-danger";
                status_flag = '<div class="bg-danger" style="font-size: 18px;font-weight: 700; text-align: center; color:#fff;">Red</div>';
            }
            console.log(status)
            $.confirm({
                icon: 'fas fa-exclamation-triangle',
                title: 'Confirmation',
                content: `Do you want to flag this course (s) as:  ${flag_type}?`,
                type: 'orange',
                animation: 'zoom',
                closeAnimation: 'scale',
                buttons: {
                    confirm: function() {
                        $.post("action.php", {
                            task: "flagThisCourse",
                            status: status,
                            course_id: course_id,
                            term_id: term_id,
                            course_name: course_name,
                            section_code: section_code,
                            total_students: total_students,
                            delivery_method: delivery_method,
                            dept_name: dept_name,
                            college_name: college_name,
                            college_id: college_id,
                            dept_id: dept_id,
                            campus_name: campus_name,

                        }).done(function(data_str) {
                            $this.parents('tr').find('.status').html(status_flag);
                            $this.parents('tr').find('.status').attr('data-status', status);

                        });
                    },
                    cancel: function() {
                        // $.alert('Canceled!');
                    }
                }
            });

        });
    },

};

$(document).ready(function() {
    "use strict";
    // $('table').DataTable();
    CovidCourseTracker.init();
});