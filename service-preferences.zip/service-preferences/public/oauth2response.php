<?php

require_once('../config/config.php');

	
$get_input = filter_input_array(INPUT_GET, FILTER_SANITIZE_STRING); // Sanitize $_GET global

if (isset($get_input['error'])) {
    ServicePreferencesUtils::instance()->exitWithError('Authentication problem: Access Denied.');
}

if (!isset($get_input['code'])) {
    ServicePreferencesUtils::instance()->exitWithError('Authentication problem, please ensure that your instance of LTI 1.0 Template is configured correctly.');
}

// get session variables
$canvas_user_id = $_SESSION['canvasUserID'];
$canvas_uri = ServicePreferencesUtils::$canvas_base_url;
$new_key = ServicePreferencesUtils::instance()->authorizeNewApiKey($canvas_uri, $get_input['code']);

// print_r($new_key->access_token);
// print_r($new_key->refresh_token);

// It should have access_token and refresh_token
if (!isset($new_key->access_token) || !isset($new_key->refresh_token)) {
    ServicePreferencesUtils::instance()->exitWithError('Authentication problem:  Please contact support.');
}

// print_r($_SESSION);
ServicePreferencesUtils::instance()->createOrUpdateUser($new_key->access_token, $new_key->refresh_token);
// if  (function_exists("sodium_crypto_secretbox")){
// 	print("here");
// 	exit();
// }
// print_r($_SESSION);
// exit();
header('Location: tool.php');
