<!DOCTYPE html>
<html>
<body>
    <style type="text/css">
        .wrapper {
            text-align: center;
            margin: 50px;
        }
        .button {
            margin: 10px;
            padding: 10px 20px;
            border: 1px solid #AAA;
            border-radius: 5px;
            color: #333;
            font-size: 1.4em;
            text-decoration: none;
        }
    </style>
    <script>
        document.cookie = 'safari_cookie_fix=fixed; path=/';
    </script>
    <div class="wrapper">
        <img src="img/tidyup_logo.png" alt="Class Covid Status Admin" />
        <h2>Welcome to Class Covid Status Admin on Safari</h2>
        <p>Please click the button below to refresh this page, so we can overcome some minor issues Safari has with embedded LTI tools.</p>
        <p>&nbsp;</p>
        <a href="/safari_redirect.php" target="_parent" class="button">
            Launch Class Covid Status Admin
        </a>

    </div>
</body>
</html>
