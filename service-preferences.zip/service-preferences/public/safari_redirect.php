<?php 
header('P3P: CP="CAO PSA OUR"');

function createCookie($options)
{
    $name = $options['name'];
    $value = $options['value'];
    $expire = isset($options['expire']) ? $options['expire'] : 0;
    $path = isset($options['path']) ? $options['path'] : '/';
    $domain = isset($options['domain']) ? $options['domain'] : NULL;
    $secure = isset($options['secure']) ? $options['secure'] : TRUE;
    $httponly = isset($options['httponly']) ? $options['httponly'] : FALSE;
    if (PHP_VERSION_ID < 70300) {
        setcookie($name, $value, $expire, "$path; samesite=None", $domain, $secure, $httponly);
    } else {
        setcookie($name, $value, [
            'expires' => $expire,
            'path' => $path,
            'domain' => $domain,
            'samesite' => 'None',
            'secure' => $secure,
            'httponly' => $httponly,
        ]);
    }
}

createCookie([
	'name' => 'safari_cookie_fix',
	'value' => 'fixed'
]);
?>
<script> window.history.back(2); </script>