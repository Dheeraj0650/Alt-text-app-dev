<?php
$app_title = 'Service Preferences';
$app_title_short = 'Service Preferences';
$app_name = 'servicepreferences';
$app_desc = 'the tool is use to record faculty member service preferences';


$servername = $_SERVER['SERVER_NAME'];
$path_exploded   = explode('/',$_SERVER['PHP_SELF']);
$scriptname = end( $path_exploded );
$scriptpath = str_replace($scriptname,'',$_SERVER['PHP_SELF']);
$launch_url = 'https://' . $servername . $scriptpath;

$get = filter_input_array(INPUT_GET, FILTER_SANITIZE_STRING);
$course_nav_default = isset($get['default']) ? $get['default'] : 'enabled';
$course_nav_enabled = isset($get['enabled']) ? $get['enabled'] : 'false';
$app_title_short = isset($get['tool_title']) ? urldecode($get['tool_title']) : $app_title_short;

header('Content-type: text/xml');

print '<?xml version="1.0" encoding="UTF-8"?>';
?>

<cartridge_basiclti_link xmlns="http://www.imsglobal.org/xsd/imslticc_v1p0"
    xmlns:blti = "http://www.imsglobal.org/xsd/imsbasiclti_v1p0"
    xmlns:lticm ="http://www.imsglobal.org/xsd/imslticm_v1p0"
    xmlns:lticp ="http://www.imsglobal.org/xsd/imslticp_v1p0"
    xmlns:xsi = "http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation = "http://www.imsglobal.org/xsd/imslticc_v1p0 http://www.imsglobal.org/xsd/lti/ltiv1p0/imslticc_v1p0.xsd
    http://www.imsglobal.org/xsd/imsbasiclti_v1p0 http://www.imsglobal.org/xsd/lti/ltiv1p0/imsbasiclti_v1p0.xsd
    http://www.imsglobal.org/xsd/imslticm_v1p0 http://www.imsglobal.org/xsd/lti/ltiv1p0/imslticm_v1p0.xsd
    http://www.imsglobal.org/xsd/imslticp_v1p0 http://www.imsglobal.org/xsd/lti/ltiv1p0/imslticp_v1p0.xsd">
    <blti:title><?= $app_title ?></blti:title>
    <blti:description><?= $app_desc ?></blti:description>
    <blti:icon>No ICO</blti:icon>
    <blti:launch_url><?= $launch_url ?></blti:launch_url>
    <blti:extensions platform="canvas.instructure.com">
      <lticm:property name="tool_id"><?= $app_name ?></lticm:property>
      <lticm:property name="privacy_level">public</lticm:property>
      <lticm:property name="domain"><?= $servername ?></lticm:property>
      <lticm:options name="user_navigation">
        <lticm:property name="url"><?= $launch_url ?></lticm:property>
        <lticm:property name="text"><?= $app_title_short ?></lticm:property>
        <lticm:property name="visibility">admins</lticm:property>
        <lticm:property name="default"><?= $course_nav_default ?></lticm:property>
        <lticm:property name="enabled"><?= $course_nav_enabled ?></lticm:property>
      </lticm:options>
    </blti:extensions>
    <cartridge_bundle identifierref="BLTI001_Bundle"/>
    <cartridge_icon identifierref="BLTI001_Icon"/>
</cartridge_basiclti_link>


