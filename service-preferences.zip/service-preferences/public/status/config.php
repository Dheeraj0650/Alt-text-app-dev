<?php
ini_set("error_reporting", "true");
error_reporting(E_ALL);

define('ENV_TYPE', 'prod');

require_once '../../lib/meekrodb.2.3.class.php';



// Database connection information for Template Wizard

DB::$host ='mysql.usu.edu';
DB::$user = 'elearnuser';
DB::$password = '4UmYcwCJbjxf00uvrNG4';
DB::$dbName = 'elearn';


if (PHP_VERSION_ID < 70300) {
    // Hack to set SAMESITE=NONE and SECURE=TRUE for the session cookie
    session_set_cookie_params(0, '/; samesite=none;', NULL, TRUE, FALSE);
} else {
    $cookieOptions = [
        'lifetime' => 0,
        'path' => '/',
        'domain' => NULL,
        'samesite' => 'None',
        'secure' => TRUE,
        'httponly' => FALSE,
    ];
    session_set_cookie_params($cookieOptions);
}

session_start();



