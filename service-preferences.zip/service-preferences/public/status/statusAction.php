<?php
    error_reporting(E_ALL);
    session_set_cookie_params(0, '/; samesite=none;', NULL, TRUE, FALSE);
    ini_set('display_errors', '1');
    require_once __DIR__.'/config.php';

    class StatusAction
    {
        public $get;
        public $post;
        private $encryption_key = 'fJQ94gwHQSi8GHmsRY0bPX4uvFXGTqfi';

        public function __construct()
        {
            $this->get = filter_input_array(INPUT_GET, FILTER_SANITIZE_STRING);
            $this->post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            if (empty($this->post)) {
                $content = trim(file_get_contents('php://input'));
                $this->post = \json_decode($content, TRUE);
            }
        }

        public function init()
        {
            if (isset($this->get['task']) && method_exists($this, $this->get['task'])) {
                $this->{$this->get['task']}();
            }
            if (isset($this->post['task']) && method_exists($this, $this->post['task'])) {
                $this->{$this->post['task']}();
            }

        }

         public function RetrieveMyCourseStatus()
        {

            $result =  DB::queryFirstRow("SELECT * FROM  cv_course_tracker WHERE course_id =%i",$_POST['course_id'] );
            print json_encode($result);

        }

    }


    $status_action = new StatusAction();

    $status_action->init();
