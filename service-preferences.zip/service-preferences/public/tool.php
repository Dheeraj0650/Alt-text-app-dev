<?php
    require_once('../config/config.php');
    $utils = ServicePreferencesUtils::instance();
?>
<!DOCTYPE html>
<html>

<head>
    <title> Covid Course Tracker</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css" integrity="sha256-bLNUHzSMEvxBhoysBE7EXYlIrmo7+n7F4oJra1IgOaM=" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
     <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.0/css/buttons.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/css/bootstrap-select.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.1/css/tempusdominus-bootstrap-4.min.css" />

    <link href="css/main.css" rel="stylesheet">
    <style type="text/css">
    .status-description {
        
        width: 150px;
        font-size: 18px;
        border-radius: unset;

    }
    .modal-body-height{
            height: 600px;
    overflow-y: auto;

    }
    .info-modal-body-height{
            height: 500px;
    overflow-y: auto;

    }

  


    </style>
</head>

<body>
    <nav class="navbar navbar-expand-md mb-4" style="color: black; background-color:#fff; border-bottom: 1px solid #c7cdd1;">
        <h2>Class Covid Status Admin</h2>
        <div class="d-flex flex-row order-2 order-lg-3">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
        <div class="row">
            <div class="col d-inline align-self-start" style="margin-left: -22px;"></div>
            <!-- <div title="User name" id="WelcomeMessage" ></div> -->
            <div class="d-none" id="user_name"></div>
        </div>
    </nav>
    <!-- The Modal -->
    <div class="modal" id="info-modal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                  <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title"></h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body modal-body-height">
                   <div class="row justify-content-md-center"  style=" text-align: center; font-size: 20px;">
                        <div class="col-8  alert alert-primary " role="alert">
                            <span class="publish-status"></span>.
                        </div>
                    </div>
                    <div class="row mb-2"  style="font-size: 20px;">
                        <div class="col" role="alert">
                            Total Students: <span class="total-student"></span>.
                        </div>
                    </div>
                    <div class="mb-2" style="font-size: 20px;">Instructor(s) Info</div>
                   <div class="row">
                        <div class="col">
                            <ol id="teacher-info"></ol>  
                        </div>
                    </div>
                    <div class="mb-2" style="font-size: 20px;">Status History</div>
                    <div class="row" >
                        <div class="col">
                             <table class="table mt-4" id="status-history-table">
                                <thead>
                                    <tr>
                                        <th>Date and Time</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>  

                        </div>
                        
                    </div>
                </div>

                  <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary send_notification">Send Notification</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="seating-modal" >
        <div class="modal-dialog modal-xl">
            <div class="modal-content">

                  <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title"></h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                  <!-- Modal body -->
                <div class="modal-body modal-body-height">
                    <div class="row text-center"><div class="col seat-data-loading "></div></div>
                    <div class="row" id="data-filter">
                        <div class="col mt-3 mb-3 ">
                            <table class="table mt-4" id="seating-list-table">
                                <thead>
                                    <tr>
                                        <th class="d-none">first_name</th>
                                        <th class="d-none">last_name</th>
                                        <th>Name</th>
                                        <th  style="max-width: 70px!important">A-Number</th>
                                        <th class="d-none">customer_id</th>
                                        <th class="d-none">group_list</th>
                                        <th>Main Class</th>
                                        <th>Recitation</th>
                                        <th>Other</th>
                                        <th>Email</th>
                                        <th  class="d-none">phone</th>
                                        <th>Phone #</th>
                                        <th style="max-width: 60px!important"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    
                    </div>
                </div>

                  <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="surrounding-seat-modal"  style="top:50px;">
        <div class="modal-dialog modal-lg" >
            <div class="modal-content">

                  <!-- Modal Header -->
                <div class="modal-header bg-primary" style="color:#fff;">
                    <h4 class="modal-title"></h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                  <!-- Modal body -->
                <div class="modal-body info-modal-body-height" >
                    <div class="row">
                        <div class="col mt-4">
                            <label for="student-main-seat">Main Class</label>
                            <select name="student-main-seat" class="form-control" id="student-main-seat">
                                <option>Select Seat</option>
                            </select>
                        </div>
                        <div class="col mt-4">
                            <label for="student-recitation-seat">Recitation</label>
                            <select name="student-recitation-seat" class="form-control" id="student-recitation-seat">
                                <option>Select Seat</option>
                            </select>
                        </div>
                        <div class="col mt-4">
                            <label for="student-other-seat">Other</label>
                            <select name="student-other-seat" class="form-control" id="student-other-seat">
                                <option>Select Seat</option>
                            </select>
                        </div>
                        
                    </div>
                    <div class="row" id="data-filter">
                        <div class="col mt-3 mb-3 ">
                            <table class="table mt-4" id="surrounding-list-table">
                                <thead>
                                    <tr>
                                        <th class="d-none">first_name</th>
                                        <th class="d-none">last_name</th>
                                        <th>Name</th>
                                        <th>A-Number</th>
                                        <th class="d-none">customer_id</th>
                                        <th class="d-none">group_list</th>
                                        <th>Seat</th>
                                        <th  class="d-none">phone</th>
                                        <th>Phone #</th>
                                        <th>Email</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>

                  <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>
        <!-- section modal -->
    <div class="modal" id="sections-modal">
        <div class="modal-dialog">
          <div class="modal-content">
          
            <!-- Modal Header -->
            <div class="modal-header">
              <h4 class="modal-title section-modal-title"></h4>
              <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
            <div class="modal-body">
                 <div class="row text-center"><div class="col section-data-loading "></div></div>
                <ul class="list-group list-group-flush course-section-list">
                </ul>
            </div>
            
            <!-- Modal footer -->
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
            
          </div>
        </div>
    </div>
    <div class="container-fluid">
        
        <ul class="nav nav-pills border-bottom">
            <li class="nav-item">
              <a class="nav-link active" style="font-size: 18px;" href="tool.php">Current Status</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" style="font-size: 18px;" href="flag.php">Search and Change Status</a>
            </li>
        </ul>
   
        <div class="row" style="margin-top: 21px;">
            <div class="col">
                <table class="table mt-4" id="flaged-course-list-table">
                    <thead>
                        <tr>
                            <th>Course Name</th>
                            <th style="width: 70px;">Status</th>
                            <th>Delivery Method</th>
                            <th>Department</th>
                            <th>Campus</th>
                            <th style="width: 200px;">Set Course Status</th>
                            <th style="width: 100px;">Course Info</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
            
        </div>
        
    </div>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://unpkg.com/popper.js/dist/umd/popper.min.js"></script>
    <script src="https://unpkg.com/tooltip.js/dist/umd/tooltip.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css" integrity="sha256-bLNUHzSMEvxBhoysBE7EXYlIrmo7+n7F4oJra1IgOaM=" crossorigin="anonymous" />
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
 
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.bootstrap4.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.colVis.min.js"></script>

    <!-- <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.print.min.js"></script> -->
    <!-- <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.colVis.min.js"></script> -->


    <script src="js/main.js?29"></script>
</body>

</html>